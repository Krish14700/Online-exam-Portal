"""Verify credentials, spreadsheet access, worksheet structure and read/write: python check_connection.py"""
import config
from services.store import build_store, StoreError, now_iso
try:
    s = build_store(config); print("Connected:", s.health())
    s.add("AuditLogs", {"log_id": "conn_test", "timestamp": now_iso(), "action": "connection_test", "status": "ok"})
    s.delete("AuditLogs", "log_id", "conn_test"); print("Read/write test passed. All 7 worksheets present.")
except StoreError as e:
    raise SystemExit(f"FAILED: {e}")
