"""Create the first administrator: python create_admin.py"""
import getpass
from werkzeug.security import generate_password_hash
import config
from services.store import build_store, now_iso
import uuid

store = build_store(config)
name = input("Admin full name: ").strip()
email = input("Admin email: ").strip().lower()
pw = getpass.getpass("Password (min 8 chars): ")
if len(pw) < 8 or pw != getpass.getpass("Repeat password: "): raise SystemExit("Passwords do not match or are too short.")
if any(u["email"] == email for u in store.all("Users")): raise SystemExit("That email already exists.")
t = now_iso()
store.add("Users", {"user_id": f"usr_{uuid.uuid4().hex[:12]}", "full_name": name, "email": email,
                    "password_hash": generate_password_hash(pw), "role": "admin", "status": "active", "created_at": t, "updated_at": t})
print("Administrator created.")
