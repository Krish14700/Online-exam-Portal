@echo off
cd /d "%~dp0"
where python >nul 2>nul || (echo Python not found. Install it from python.org and tick "Add to PATH". & pause & exit /b 1)
if not exist .venv ( python -m venv .venv || (echo Could not create venv & pause & exit /b 1) )
call .venv\Scripts\activate.bat
if not exist .env copy .env.example .env >nul
python -m pip install -q -r requirements.txt || (echo Package install failed. Check your internet. & pause & exit /b 1)
python app.py
pause
