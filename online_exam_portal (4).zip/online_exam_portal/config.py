import os, secrets
from pathlib import Path

BASE = Path(__file__).resolve().parent
try:
    from dotenv import load_dotenv
    load_dotenv(BASE / ".env")
except ImportError:          # app still runs with plain environment variables
    pass

def flag(name, default="false"):
    return os.getenv(name, default).strip().lower() == "true"

# STORAGE: "local" (JSON file, persistent, easiest), "google" (Google Sheets), "memory" (tests/demo)
STORAGE = os.getenv("STORAGE", "").strip().lower()
if not STORAGE:
    STORAGE = "memory" if flag("DEMO_MODE") else ("google" if os.getenv("GOOGLE_SHEET_ID", "").strip() not in ("", "your_google_spreadsheet_id") else "local")

SHEET_ID = os.getenv("GOOGLE_SHEET_ID", "").strip()
CREDENTIALS = str(BASE / os.getenv("GOOGLE_APPLICATION_CREDENTIALS", "credentials/service_account.json"))
LOCAL_DB = BASE / "data" / "local_db.json"
DEBUG = flag("FLASK_DEBUG")
COOKIE_SECURE = flag("COOKIE_SECURE")
ADMIN_EMAIL = os.getenv("ADMIN_EMAIL", "admin@example.com").strip().lower()
ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "Admin@12345")

def get_secret():
    """Use FLASK_SECRET_KEY if real; otherwise create and remember one so logins survive restarts."""
    s = os.getenv("FLASK_SECRET_KEY", "").strip()
    if s and not s.startswith("replace-with"): return s
    f = BASE / "data" / "secret_key.txt"
    f.parent.mkdir(exist_ok=True)
    if not f.exists(): f.write_text(secrets.token_hex(32))
    return f.read_text().strip()

# --- Proctoring ---------------------------------------------------------------
# After this many violations (tab switch, window blur, camera off) the exam is submitted automatically.
MAX_VIOLATIONS = int(os.getenv("MAX_VIOLATIONS", "3"))
# Local/memory mode only: create demo teacher, student and a sample exam on first start.
SEED_DEMO = flag("SEED_DEMO", "true")
