"""
Storage layer for ExamDesk
==========================
Three interchangeable back-ends with the SAME methods, so app.py never cares which is used:

    all(sheet)                      -> list of row dicts
    add(sheet, row)                 -> append one row
    update(sheet, key, value, new)  -> change the row where row[key] == value
    delete(sheet, key, value)       -> remove that row
    health()                        -> {"ok": True, "backend": "..."}

    MemoryStore  - temporary, for tests
    FileStore    - saves to data/local_db.json (default; no setup needed)
    SheetsStore  - Google Sheets via a service account
"""
import copy
import json
import logging
import os
import threading
import time
from datetime import datetime, timezone

log = logging.getLogger("store")

# Worksheet name -> column headers. Order matters: it is the column order in Google Sheets.
SCHEMA = {
    "Users": ["user_id", "full_name", "email", "password_hash", "role", "status", "created_at", "updated_at"],
    "Exams": ["exam_id", "title", "description", "subject", "duration_minutes", "total_questions", "total_marks",
              "passing_percentage", "negative_marking_enabled", "negative_marks_per_wrong_answer",
              "start_datetime", "end_datetime", "status", "created_by", "created_at", "updated_at"],
    "Questions": ["question_id", "exam_id", "question_text", "option_a", "option_b", "option_c", "option_d",
                  "correct_option", "marks", "explanation", "question_order", "created_at", "updated_at"],
    "Attempts": ["attempt_id", "user_id", "exam_id", "attempt_number", "started_at", "expires_at", "submitted_at",
                 "status", "total_questions", "answered_questions", "unanswered_questions", "score", "percentage",
                 "result_status"],
    "Responses": ["response_id", "attempt_id", "question_id", "selected_option", "is_correct", "marks_awarded",
                  "answered_at", "marked_for_review"],
    "Results": ["result_id", "attempt_id", "user_id", "exam_id", "total_questions", "correct_answers",
                "incorrect_answers", "unanswered_questions", "total_marks", "marks_obtained", "percentage",
                "passing_percentage", "result_status", "completed_at"],
    "Violations": ["violation_id", "attempt_id", "user_id", "exam_id", "type", "timestamp", "details"],
    "AuditLogs": ["log_id", "actor_user_id", "action", "entity_type", "entity_id", "timestamp", "status", "details"],
}


def now_iso():
    """UTC timestamp in ISO 8601, e.g. 2026-10-28T09:30:00+00:00."""
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


class StoreError(Exception):
    """A database problem. The message is safe to show users (never contains credentials)."""


# ---------------------------------------------------------------------------
# MemoryStore: everything lives in a Python dict and disappears when the app stops.
# ---------------------------------------------------------------------------
class MemoryStore:
    kind = "memory (temporary)"

    def __init__(self):
        self.t = {name: [] for name in SCHEMA}
        self.lock = threading.RLock()       # Flask is multi-threaded; protect the lists

    def all(self, sheet):
        with self.lock:
            return copy.deepcopy(self.t[sheet])    # copies, so callers cannot change stored rows by accident

    def add(self, sheet, row):
        with self.lock:
            # Keep only known columns; missing ones become empty strings.
            self.t[sheet].append({c: row.get(c, "") for c in SCHEMA[sheet]})

    def update(self, sheet, key, value, changes):
        with self.lock:
            for r in self.t[sheet]:
                if str(r[key]) == str(value):
                    r.update({k: v for k, v in changes.items() if k in SCHEMA[sheet]})
                    return True
            return False

    def delete(self, sheet, key, value):
        with self.lock:
            before = len(self.t[sheet])
            self.t[sheet] = [r for r in self.t[sheet] if str(r[key]) != str(value)]
            return len(self.t[sheet]) < before

    def health(self):
        return {"ok": True, "backend": self.kind}


# ---------------------------------------------------------------------------
# FileStore: MemoryStore + automatic saving to a JSON file.
# ---------------------------------------------------------------------------
class FileStore(MemoryStore):
    """Persistent, works offline. Good for one PC / classroom demo, not for hundreds of users."""

    def __init__(self, path):
        super().__init__()
        self.path = path
        self.kind = f"local file ({path.name})"
        if path.exists():
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
            except ValueError:
                raise StoreError(f"{path} is damaged. Rename or delete it to start fresh.")
            for name in SCHEMA:
                self.t[name] = data.get(name, [])

    def _save(self):
        """Write to a temp file then swap it in, so a crash can never leave a half-written database."""
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(self.t), encoding="utf-8")
        os.replace(tmp, self.path)

    # Each write runs under the lock so the in-memory change and the file save stay together.
    def add(self, sheet, row):
        with self.lock:
            super().add(sheet, row)
            self._save()

    def update(self, sheet, key, value, changes):
        with self.lock:
            done = super().update(sheet, key, value, changes)
            if done:
                self._save()
            return done

    def delete(self, sheet, key, value):
        with self.lock:
            done = super().delete(sheet, key, value)
            if done:
                self._save()
            return done


# ---------------------------------------------------------------------------
# SheetsStore: Google Sheets through gspread.
# ---------------------------------------------------------------------------
class SheetsStore:
    kind = "google-sheets"
    CACHE_SECONDS = 4   # reads are reused for a few seconds -> far fewer API calls (Google allows ~60 reads/min)

    def __init__(self, sheet_id, cred_path):
        try:
            import gspread
            from google.oauth2.service_account import Credentials
        except ImportError:
            raise StoreError("Google packages missing. Run: python -m pip install gspread google-auth")
        self.gspread = gspread
        self.lock = threading.RLock()
        self.cache = {}                     # sheet -> (timestamp, rows)
        scopes = ["https://www.googleapis.com/auth/spreadsheets"]
        try:
            creds = Credentials.from_service_account_file(cred_path, scopes=scopes)
            self.book = gspread.authorize(creds).open_by_key(sheet_id)
        except FileNotFoundError:
            raise StoreError(f"Credentials file not found: {cred_path}. Put your service account JSON key there.")
        except gspread.exceptions.SpreadsheetNotFound:
            raise StoreError("Spreadsheet not found. Check GOOGLE_SHEET_ID and share the sheet with the "
                             "service account email as Editor.")
        except Exception as exc:            # deliberately generic: never print key contents
            raise StoreError(f"Could not connect to Google Sheets ({type(exc).__name__}). "
                             "Check the credentials file and GOOGLE_SHEET_ID.")
        self.ws = {}
        self._ensure_schema()

    def _retry(self, fn, tries=4):
        """Run an API call; wait 1s, 2s, 4s between retries for temporary failures (rate limit, network)."""
        for attempt in range(tries):
            try:
                return fn()
            except self.gspread.exceptions.APIError as exc:
                code = getattr(exc.response, "status_code", 0)
                if code in (429, 500, 502, 503) and attempt < tries - 1:
                    time.sleep(2 ** attempt)
                    continue
                if code == 429:
                    raise StoreError("Google Sheets is busy (rate limit). Wait a minute and try again.")
                if code in (401, 403):
                    raise StoreError("Google Sheets refused access. Share the sheet with the service account (Editor).")
                raise StoreError(f"Google Sheets API error ({code}).")
            except (ConnectionError, TimeoutError, OSError):
                if attempt < tries - 1:
                    time.sleep(2 ** attempt)
                    continue
                raise StoreError("Network problem reaching Google Sheets. Check your internet connection.")

    def _ensure_schema(self):
        """Create missing worksheets + headers; refuse to run if someone changed the headers."""
        existing = {w.title: w for w in self._retry(self.book.worksheets)}
        for name, cols in SCHEMA.items():
            sheet = existing.get(name) or self._retry(lambda: self.book.add_worksheet(name, 1000, len(cols)))
            header = self._retry(lambda: sheet.row_values(1))
            if not header:
                self._retry(lambda: sheet.update([cols], "A1", value_input_option="RAW"))
            elif header != cols:
                raise StoreError(f"Worksheet '{name}' has unexpected column headers. Expected: {', '.join(cols)}")
            self.ws[name] = sheet

    def all(self, sheet):
        with self.lock:
            hit = self.cache.get(sheet)
            if hit and time.time() - hit[0] < self.CACHE_SECONDS:
                return copy.deepcopy(hit[1])
            rows = self._retry(lambda: self.ws[sheet].get_all_records(numericise_ignore=["all"]))
            self.cache[sheet] = (time.time(), rows)
            return copy.deepcopy(rows)

    def add(self, sheet, row):
        with self.lock:
            values = [str(row.get(c, "")) for c in SCHEMA[sheet]]
            self._retry(lambda: self.ws[sheet].append_row(values, value_input_option="RAW"))
            self.cache.pop(sheet, None)             # data changed -> drop cached copy

    def update(self, sheet, key, value, changes):
        with self.lock:
            self.cache.pop(sheet, None)             # always read fresh before writing
            for i, r in enumerate(self.all(sheet)):
                if str(r[key]) == str(value):
                    r.update({k: v for k, v in changes.items() if k in SCHEMA[sheet]})
                    values = [[str(r[c]) for c in SCHEMA[sheet]]]
                    # BUG FIX: value_input_option="RAW" stops Google turning "2026-10-28T..." into a date
                    # or "true" into a checkbox, which broke timestamp parsing on later reads.
                    self._retry(lambda: self.ws[sheet].update(values, f"A{i + 2}", value_input_option="RAW"))
                    self.cache.pop(sheet, None)
                    return True
            return False

    def delete(self, sheet, key, value):
        with self.lock:
            self.cache.pop(sheet, None)
            for i, r in enumerate(self.all(sheet)):
                if str(r[key]) == str(value):
                    self._retry(lambda: self.ws[sheet].delete_rows(i + 2))
                    self.cache.pop(sheet, None)
                    return True
            return False

    def health(self):
        self._retry(lambda: self.ws["Users"].row_values(1))
        return {"ok": True, "backend": self.kind}


def build_store(cfg):
    """Pick the back-end named by STORAGE in .env."""
    if cfg.STORAGE == "memory":
        return MemoryStore()
    if cfg.STORAGE == "local":
        return FileStore(cfg.LOCAL_DB)
    if cfg.STORAGE == "google":
        if not cfg.SHEET_ID:
            raise StoreError("STORAGE=google but GOOGLE_SHEET_ID is empty in .env. "
                             "Use STORAGE=local to run without Google.")
        return SheetsStore(cfg.SHEET_ID, cfg.CREDENTIALS)
    raise StoreError(f"STORAGE='{cfg.STORAGE}' is not valid. Use local, google or memory.")
