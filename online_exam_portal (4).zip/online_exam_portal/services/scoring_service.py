"""Pure scoring logic - runs only on the server."""
def score_attempt(questions, answers, negative_enabled, negative_marks, passing_pct):
    """questions: dicts with question_id, correct_option, marks. answers: {question_id: 'A'..'D'}."""
    total = sum(float(q["marks"]) for q in questions)
    correct = wrong = blank = 0
    obtained = 0.0
    detail = {}
    for q in questions:
        qid, marks = q["question_id"], float(q["marks"])
        sel = answers.get(qid)
        if not sel:
            blank += 1; detail[qid] = (False, 0.0)
        elif sel == q["correct_option"]:
            correct += 1; obtained += marks; detail[qid] = (True, marks)
        else:
            wrong += 1; pen = -float(negative_marks) if negative_enabled else 0.0
            obtained += pen; detail[qid] = (False, pen)
    obtained = round(obtained, 2)
    pct = round(obtained / total * 100, 2) if total > 0 else 0.0
    return {"correct": correct, "incorrect": wrong, "unanswered": blank, "total_marks": total,
            "marks_obtained": obtained, "percentage": pct,
            "result_status": "PASS" if total > 0 and pct >= float(passing_pct) else "FAIL", "detail": detail}
