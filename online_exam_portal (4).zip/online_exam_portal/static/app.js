"use strict";
/* =====================================================================
   ExamDesk front-end (single-page app, hash routing)
   ---------------------------------------------------------------------
   PAGES
   Public : #/  #/features  #/how-it-works  #/faq  #/about  #/contact  #/login  #/register
   Student: #/dashboard  #/exam/:id  #/take/:attemptId  #/result/:id  #/history  #/profile
   Staff  : #/admin  #/admin/exams  #/admin/questions/:id  #/admin/results  #/admin/proctoring
   Admin  : #/admin/students  #/admin/audit
   ===================================================================== */

// ---------- tiny helpers ----------
const $ = s => document.querySelector(s);
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));   // stops HTML injection
let me = null;          // logged-in user (null = not loaded yet / logged out)
let csrf = "";          // anti-CSRF token sent with every write request
let timerId = null;     // exam countdown interval
let camStream = null;   // live webcam stream (kept between the instructions page and the exam)
let cleanupTake = null; // function that removes exam listeners when you leave the exam page

const isStaff = () => me && (me.role === "admin" || me.role === "teacher");

/** Talk to the Flask API. Throws Error(message) on any problem. */
async function api(path, method = "GET", body) {
  const opts = {method, headers: {"Content-Type": "application/json", "X-CSRF-Token": csrf}};
  if (body !== undefined) opts.body = JSON.stringify(body);
  let r; try { r = await fetch(path, opts); } catch { throw new Error("Cannot reach the server. Check that it is still running."); }
  if (r.headers.get("content-type")?.includes("text/csv")) return r;
  let d;
  try { d = await r.json(); } catch { throw new Error("The server sent an unexpected reply."); }
  // Session expired -> go to login instead of showing a broken page.
  if (r.status === 401 && !path.startsWith("/api/auth/")) { me = null; csrf = ""; nav(); location.hash = "#/login"; throw new Error("Your session ended. Please log in again."); }
  if (!d.ok) { const e = new Error(d.error || "Request failed"); e.status = r.status; throw e; }
  return d;
}
function toast(msg, bad) { const t = document.createElement("div"); t.className = "toast" + (bad ? " bad" : ""); t.textContent = msg; $("#toasts").append(t); setTimeout(() => t.remove(), 5000); }

/** Modal dialog. Resolves true when the user presses the confirm button. Inputs stay readable afterwards. */
function confirmDlg(html, yes = "Confirm") {
  return new Promise(res => { const d = $("#dlg"); d.innerHTML = `${html}<div class="row" style="margin-top:1rem"><button class="primary" id="y">${yes}</button><button id="n">Cancel</button></div>`;
    d.showModal(); $("#y").onclick = () => { d.close(); res(true); }; $("#n").onclick = () => { d.close(); res(false); }; d.onclose = () => res(false); });
}
/** Disable a button while its async action runs (stops double clicks). */
async function busy(btn, fn) { btn.disabled = true; const t = btn.textContent; btn.textContent = "Working…"; try { return await fn(); } catch (e) { toast(e.message, true); } finally { btn.disabled = false; btn.textContent = t; } }

function stopCam() { if (camStream) { camStream.getTracks().forEach(t => t.stop()); camStream = null; } }
const camAlive = () => !!camStream && camStream.getVideoTracks().some(t => t.readyState === "live" && t.enabled && !t.muted);
/** Ask the browser for the webcam. Needs http://127.0.0.1 / localhost or https. */
async function startCamera() {
  if (!navigator.mediaDevices?.getUserMedia) throw new Error("Camera is not available. Use Chrome or Edge and open http://127.0.0.1:5000 (or HTTPS).");
  try { stopCam(); camStream = await navigator.mediaDevices.getUserMedia({video: {width: 320, height: 240}, audio: false}); return camStream; }
  catch (e) { throw new Error(e.name === "NotAllowedError" ? "Camera permission was blocked. Click the camera icon in the address bar, allow it, and try again."
    : e.name === "NotFoundError" ? "No camera was found on this device." : "Could not start the camera: " + e.name); }
}

/** Replace the page content. Also stops the camera and exam listeners unless `keepCam` is true. */
function show(html, keepCam = false) {
  clearInterval(timerId);
  if (cleanupTake) { cleanupTake(); cleanupTake = null; }
  if (!keepCam) stopCam();
  const v = $("#view"); v.innerHTML = html; v.focus({preventScroll: true}); window.scrollTo(0, 0);
}

// ---------- header navigation ----------
function nav() {
  const link = (h, t) => `<a href="${h}">${t}</a>`;
  let items;
  if (!me) items = link("#/features", "Features") + link("#/how-it-works", "How it works") + link("#/faq", "FAQ") + link("#/contact", "Contact") + link("#/login", "Log in") + `<a class="btn primary" href="#/register">Register</a>`;
  else if (me.role === "student") items = link("#/dashboard", "Exams") + link("#/history", "My results") + link("#/profile", "Profile");
  else items = link("#/admin", "Dashboard") + link("#/admin/exams", "Exams") + link("#/admin/results", "Results") + link("#/admin/proctoring", "Proctoring")
    + (me.role === "admin" ? link("#/admin/students", "Users") + link("#/admin/audit", "Audit log") : "") + link("#/profile", "Profile");
  $("#top").innerHTML = `<a class="logo" href="#/">ExamDesk</a><nav>${items}${me ? `<span class="pill role">${me.role}</span><button id="out">Log out</button>` : ""}</nav>`;
  if (me) $("#out").onclick = async () => { await api("/api/auth/logout", "POST").catch(() => {}); me = null; csrf = ""; nav(); location.hash = "#/"; route(); };
}
const footer = () => `<footer><a href="#/about">About</a> · <a href="#/faq">FAQ</a> · <a href="#/contact">Contact</a><br>ExamDesk – online MCQ examinations</footer>`;

// =====================================================================
//  VIEWS
// =====================================================================
const views = {
  // ---------------- PUBLIC PAGES ----------------
  home: () => show(`<section class="hero"><h1>Create exams. Take exams. Results the second you submit.</h1>
    <p class="mute">Timed MCQ exams with live camera proctoring, tab-switch warnings and automatic marking.</p>
    <a class="btn primary" href="#/register">Create an account</a> <a class="btn" href="#/login">Log in</a></section>
    <div class="grid"><div class="card"><h3>👩‍🏫 Teachers &amp; admins</h3><p>Build exam papers, add questions, publish with one click and export results.</p></div>
    <div class="card"><h3>🎓 Students</h3><p>Take timed exams, review answers and keep a history of your results.</p></div>
    <div class="card"><h3>📷 Proctored</h3><p>A live camera is required and leaving the exam tab triggers warnings.</p></div></div>${footer()}`),

  features: () => show(`<h2>Features</h2><div class="grid">${[
    ["Three login types", "Separate student, teacher and administrator accounts with role-based access."],
    ["Exam paper builder", "Create an exam, add MCQs with marks and explanations, then publish."],
    ["Live camera required", "Students must keep their webcam on for the whole exam."],
    ["Tab-switch warnings", "Leaving the exam tab shows a warning; too many warnings submit the exam."],
    ["Instant marking", "Marked on the server with optional negative marking and a pass mark."],
    ["Reports", "Filter results, view the proctoring log and export CSV."]].map(([t, p]) => `<div class="card"><h3>${t}</h3><p>${p}</p></div>`).join("")}</div>${footer()}`),

  howitworks: () => show(`<h2>How it works</h2><div class="card"><ol class="steps"><li><b>Teacher or admin</b> creates an exam and adds questions.</li><li>They <b>publish</b> it, so it appears for students.</li>
    <li>The <b>student</b> logs in, reads the instructions and turns on the camera.</li><li>The exam runs with a server-controlled timer. Switching tabs gives a warning.</li>
    <li>On submit the server marks the exam and the <b>result appears instantly</b>.</li><li>Staff review results and the proctoring log.</li></ol></div>${footer()}`),

  faq: () => show(`<h2>Frequently asked questions</h2>${[
    ["Why does the exam need my camera?", "Proctoring. The camera must stay on during the exam. The video is shown to you only and is not recorded or uploaded."],
    ["What happens if I switch tabs?", "You get a warning and the event is logged. After the maximum number of warnings the exam is submitted automatically."],
    ["Can I retake an exam?", "No. Each student gets one attempt per exam."],
    ["What if my internet drops?", "Answers are saved as you click. Reload the page to continue; the timer keeps running on the server."],
    ["How do teachers join?", "Register as a teacher. An administrator approves the account before you can log in."]]
    .map(([q, a]) => `<details class="card" style="margin-bottom:.6rem"><summary><b>${q}</b></summary><p>${a}</p></details>`).join("")}${footer()}`),

  about: () => show(`<h2>About ExamDesk</h2><div class="card"><p>ExamDesk is a Flask and JavaScript exam portal. Marking, timing and answer keys live on the server so nothing can be changed from the browser.</p>
    <p class="mute">Note: browser-based proctoring discourages cheating but cannot make it impossible. For high-stakes exams add in-person or dedicated proctoring.</p></div>${footer()}`),

  contact: () => { show(`<form class="card" id="f"><h2>Contact us</h2><label for="cn">Your name</label><input id="cn" required minlength="2"><label for="ce">Email</label><input id="ce" type="email" required>
    <label for="cm">Message</label><textarea id="cm" rows="4" required minlength="5"></textarea><p><button class="primary">Send message</button></p></form>${footer()}`);
    $("#f").onsubmit = ev => { ev.preventDefault(); busy(ev.submitter, async () => { const d = await api("/api/contact", "POST", {name: $("#cn").value, email: $("#ce").value, message: $("#cm").value}); toast(d.message); $("#f").reset(); }); }; },

  // ---------------- LOGIN (3 role tabs) ----------------
  login: async () => {
    let role = "student", demo = false;
    try { const h = await api("/api/health"); demo = /local|memory/.test(h.backend); } catch {}
    const demoCreds = {student: ["student@example.com", "Student@12345"], teacher: ["teacher@example.com", "Teacher@12345"], admin: ["admin@example.com", "Admin@12345"]};
    const draw = () => { show(`<form class="card" id="f"><h2>Log in</h2><div class="tabs" role="tablist">${["student", "teacher", "admin"].map(r =>
      `<button type="button" role="tab" aria-selected="${r === role}" class="tab ${r === role ? "on" : ""}" data-r="${r}">${r[0].toUpperCase() + r.slice(1)}</button>`).join("")}</div>
      <label for="e">Email</label><input id="e" type="email" required autocomplete="username"><label for="p">Password</label><input id="p" type="password" required autocomplete="current-password">
      <p><button class="primary">Log in as ${role}</button></p>${demo ? `<p class="mute">Demo: <button type="button" id="fill">Fill ${role} demo login</button></p>` : ""}
      <p class="mute">${role === "admin" ? "" : `No account? <a href="#/register">Register</a>`}</p></form>`);
      document.querySelectorAll(".tab").forEach(b => b.onclick = () => { role = b.dataset.r; draw(); });
      if (demo) $("#fill").onclick = () => { $("#e").value = demoCreds[role][0]; $("#p").value = demoCreds[role][1]; };
      $("#f").onsubmit = ev => { ev.preventDefault(); busy(ev.submitter, async () => {
        const d = await api("/api/auth/login", "POST", {email: $("#e").value, password: $("#p").value, role});
        me = d.user; csrf = d.csrf; nav(); const target = me.role === "student" ? "#/dashboard" : "#/admin";
        if (location.hash === target) route(); else location.hash = target; }); }; };
    draw();
  },

  register: () => { let role = "student";
    const draw = () => { show(`<form class="card" id="f"><h2>Create account</h2><div class="tabs">${["student", "teacher"].map(r => `<button type="button" class="tab ${r === role ? "on" : ""}" data-r="${r}">${r[0].toUpperCase() + r.slice(1)}</button>`).join("")}</div>
      ${role === "teacher" ? '<p class="mute">Teacher accounts need administrator approval before first login.</p>' : ""}
      <label for="n">Full name</label><input id="n" required minlength="2"><label for="e">Email</label><input id="e" type="email" required>
      <label for="p">Password (8+ characters)</label><input id="p" type="password" required minlength="8" autocomplete="new-password"><p><button class="primary">Register as ${role}</button></p></form>`);
      document.querySelectorAll(".tab").forEach(b => b.onclick = () => { role = b.dataset.r; draw(); });
      $("#f").onsubmit = ev => { ev.preventDefault(); busy(ev.submitter, async () => { const d = await api("/api/auth/register", "POST", {full_name: $("#n").value, email: $("#e").value, password: $("#p").value, role}); toast(d.message); location.hash = "#/login"; }); }; };
    draw(); },

  // ---------------- STUDENT PAGES ----------------
  dashboard: async () => {
    const [ex, rs] = await Promise.all([api("/api/exams"), api("/api/results")]);
    const avg = rs.results.length ? (rs.results.reduce((s, r) => s + +r.percentage, 0) / rs.results.length).toFixed(1) : "–";
    const open = ex.exams.filter(e => !e.completed), done = ex.exams.filter(e => e.completed);
    show(`<h2>Welcome, ${esc(me.full_name)}</h2><div class="grid"><div class="card stat"><b>${rs.results.length}</b>Exams completed</div><div class="card stat"><b>${avg}${avg === "–" ? "" : "%"}</b>Average score</div><div class="card stat"><b>${open.length}</b>Available now</div></div>
      <h3>Available exams</h3><div class="grid">${open.map(e => `<div class="card"><h3>${esc(e.title)}</h3><p class="mute">${esc(e.subject)} · ${e.duration_minutes} min · ${e.total_questions} questions</p><a class="btn primary" href="#/exam/${e.exam_id}">View instructions</a></div>`).join("") || '<p class="mute">No exams are available right now.</p>'}</div>
      <h3>Completed</h3><div class="grid">${done.map(e => `<div class="card"><b>${esc(e.title)}</b><p><span class="pill">Completed</span></p></div>`).join("") || '<p class="mute">Nothing yet.</p>'}</div>`);
  },

  /** Instructions page + camera check. Start stays disabled until the camera is live. */
  instructions: async id => {
    const e = (await api("/api/exams")).exams.find(x => x.exam_id === id); if (!e) return show("<p>Exam not found.</p>");
    show(`<div class="card"><h2>${esc(e.title)}</h2><p>${esc(e.description)}</p><ul><li>Duration: ${e.duration_minutes} minutes (timed by the server)</li><li>${e.total_questions} questions, ${e.total_marks} marks · pass mark ${e.passing_percentage}%</li>
      <li>Wrong answer penalty: ${e.negative_marking_enabled === "true" ? e.negative_marks_per_wrong_answer + " marks" : "none"}</li><li>Answers save as you go. Submission is final.</li></ul>
      <div class="warnbox"><b>Proctoring rules</b><ul><li>Your <b>camera must stay on</b> for the whole exam (video is not recorded or uploaded).</li><li>Do <b>not switch tabs or windows</b>. Each time gives a warning; after several the exam is submitted automatically.</li></ul></div>
      <video id="pv" class="campreview" autoplay muted playsinline aria-label="Your camera preview"></video><p id="cs" class="mute">Camera is off.</p>
      <div class="row"><button id="cam">Turn on camera</button><button class="primary" id="go" disabled>Start exam</button></div></div>`, true);
    const attach = () => { $("#pv").srcObject = camStream; $("#cs").textContent = "Camera is on ✔"; $("#go").disabled = false; };
    if (camAlive()) attach();
    $("#cam").onclick = ev => busy(ev.target, async () => { try { await startCamera(); attach(); } catch (er) { toast(er.message, true); $("#cs").textContent = er.message; } });
    $("#go").onclick = ev => busy(ev.target, async () => { if (!camAlive()) return toast("Turn the camera on first.", true); const a = await api(`/api/exams/${id}/attempts`, "POST"); location.hash = "#/take/" + a.attempt_id; });
  },

  /** The exam itself, with timer, palette, camera preview and proctoring. */
  take: async aid => {
    let d; try { d = await api("/api/attempts/" + aid); } catch (e) { toast(e.message, true); return location.hash = "#/history"; }
    const Q = d.questions, R = d.responses, MAX = d.max_violations;
    let i = 0, left = d.seconds_left, submitting = false, strikes = d.violations || 0, camLost = false, lastSent = 0, chain = Promise.resolve();
    const answered = q => !!R[q.question_id]?.selected;

    show(`<div class="row card" style="justify-content:space-between"><b>${esc(d.exam.title)}</b><span id="prog"></span><span class="timer" id="tm" role="timer"></span><span id="st" class="mute"></span><button class="primary" id="sub">Submit exam</button></div>
      <div class="exam" style="margin-top:1rem"><div class="card" id="examcard"><div id="q"></div><div class="row" style="margin-top:1rem"><button id="pv">Previous</button><button id="nx">Next</button><button id="rv">Mark for review</button><button id="cl">Clear answer</button></div></div>
      <aside class="card"><video id="cam" class="campreview" autoplay muted playsinline aria-label="Your live camera"></video><p class="mute" id="strikes"></p><h4>Questions</h4><div class="pal" id="pal"></div>
      <p class="mute" style="font-size:.85rem">Green: answered · Dashed ⚑: marked for review · Outlined: current</p></aside></div>
      <div class="overlay" id="camgate" hidden><div class="card"><h3>📷 Camera required</h3><p id="camgmsg">Turn on your camera to continue. The exam timer keeps running.</p><button class="primary" id="camon">Turn on camera</button></div></div>
      <div class="overlay" id="warn" hidden><div class="card"><h3>⚠️ Warning</h3><p id="warnmsg"></p><button class="primary" id="warnok">I understand</button></div></div>`, true);

    const draw = () => { const q = Q[i], r = R[q.question_id] || {};
      $("#q").innerHTML = `<p class="mute">Question ${i + 1} of ${Q.length} · ${q.marks} mark(s)</p><h3>${esc(q.question_text)}</h3>` +
        ["A","B","C","D"].map(L => `<label class="opt ${r.selected === L ? "sel" : ""}"><input type="radio" name="o" value="${L}" ${r.selected === L ? "checked" : ""}><span><b>${L}.</b> ${esc(q["option_" + L.toLowerCase()])}</span></label>`).join("");
      document.querySelectorAll("input[name=o]").forEach(el => el.onchange = () => save(el.value));
      $("#pal").innerHTML = Q.map((x, k) => `<button class="${answered(x) ? "ans" : ""} ${R[x.question_id]?.review ? "rev" : ""} ${k === i ? "cur" : ""}" data-k="${k}" aria-label="Question ${k + 1}${answered(x) ? ", answered" : ", not answered"}${R[x.question_id]?.review ? ", marked for review" : ""}">${k + 1}</button>`).join("");
      document.querySelectorAll("#pal button").forEach(b => b.onclick = () => { i = +b.dataset.k; draw(); });
      $("#prog").textContent = `${Q.filter(answered).length}/${Q.length} answered`;
      $("#strikes").textContent = `Warnings: ${strikes} of ${MAX}`; };

    // Saves run one after another so the LAST click is never lost.
    function save(sel, review) { const q = Q[i], r = R[q.question_id] = R[q.question_id] || {};
      if (sel !== undefined) r.selected = sel; if (review !== undefined) r.review = review; draw(); $("#st").textContent = "Saving…";
      const body = {question_id: q.question_id, selected_option: r.selected || "", marked_for_review: !!r.review};
      chain = chain.then(async () => { try { await api(`/api/attempts/${aid}/responses`, "PUT", body); $("#st").textContent = "Saved"; } catch (e) { $("#st").textContent = "Not saved"; toast(e.message, true); } });
      return chain; }

    async function finish() { if (submitting) return; submitting = true; clearInterval(timerId); await chain;
      try { const res = (await api(`/api/attempts/${aid}/submit`, "POST")).result; location.hash = "#/result/" + res.result_id; }
      catch (e) { submitting = false; timerId = setInterval(tick, 1000); toast(e.message + " Your answers are saved; try submitting again.", true); } }

    // ----- proctoring -----
    const showWarn = msg => { $("#warnmsg").textContent = msg; $("#warn").hidden = false; };
    /** Tell the server about a rule break; the server counts it and may end the exam. */
    async function violation(type, text) {
      if (submitting) return;
      const now = Date.now(); if (now - lastSent < 2000) return; lastSent = now;   // one event per 2 seconds
      let info = {count: strikes + 1, limit: MAX, auto_submitted: false};
      try { info = await api(`/api/attempts/${aid}/violations`, "POST", {type}); } catch {}
      strikes = info.count; draw();
      if (info.auto_submitted) { submitting = true; toast("Exam submitted automatically: too many violations.", true); location.hash = "#/result/" + info.result_id; return; }
      showWarn(`${text} Warning ${info.count} of ${info.limit}. At ${info.limit} warnings your exam is submitted automatically.`);
    }
    const onVis = () => { if (document.hidden) violation("tab_switch", "You left the exam tab."); };
    const onBlur = () => setTimeout(() => { if (!submitting) violation(document.hidden ? "tab_switch" : "window_blur", document.hidden ? "You left the exam tab." : "You clicked outside the exam window."); }, 150);
    const block = ev => ev.preventDefault();                        // no copy / paste / right-click inside the exam
    const camWatch = () => { if (camAlive() || submitting) return; if (!camLost) { camLost = true; $("#camgate").hidden = false; violation("camera_off", "Your camera was turned off."); } };
    const camBack = async () => { try { await startCamera(); $("#cam").srcObject = camStream; camLost = false; $("#camgate").hidden = true; } catch (e) { $("#camgmsg").textContent = e.message; } };
    const beforeUnload = ev => { if (!submitting) { ev.preventDefault(); ev.returnValue = ""; } };
    document.addEventListener("visibilitychange", onVis); window.addEventListener("blur", onBlur); window.addEventListener("beforeunload", beforeUnload);
    ["copy", "cut", "paste", "contextmenu"].forEach(t => document.addEventListener(t, block));
    const camTimer = setInterval(camWatch, 1500);
    cleanupTake = () => { document.removeEventListener("visibilitychange", onVis); window.removeEventListener("blur", onBlur); window.removeEventListener("beforeunload", beforeUnload);
      ["copy", "cut", "paste", "contextmenu"].forEach(t => document.removeEventListener(t, block)); clearInterval(camTimer); };

    $("#warnok").onclick = () => $("#warn").hidden = true; $("#camon").onclick = camBack;
    $("#pv").onclick = () => { i = Math.max(0, i - 1); draw(); }; $("#nx").onclick = () => { i = Math.min(Q.length - 1, i + 1); draw(); };
    $("#rv").onclick = () => save(undefined, !(R[Q[i].question_id]?.review)); $("#cl").onclick = () => save("");
    $("#sub").onclick = async () => { const a = Q.filter(answered).length, m = Q.filter(x => R[x.question_id]?.review).length;
      if (await confirmDlg(`<h3>Submit exam?</h3><p>Total: ${Q.length}<br>Answered: ${a}<br>Unanswered: ${Q.length - a}<br>Marked for review: ${m}</p><p class="badtxt"><b>Submission is final.</b></p>`, "Submit")) finish(); };
    const tick = () => { const m = Math.max(0, Math.floor(left / 60)), s = Math.max(0, left % 60); $("#tm").textContent = `${m}:${String(s).padStart(2, "0")}`; $("#tm").classList.toggle("low", left <= 60); if (left <= 0) finish(); left--; };
    draw(); tick(); timerId = setInterval(tick, 1000);
    if (camAlive()) $("#cam").srcObject = camStream; else { camLost = true; $("#camgate").hidden = false; }   // e.g. page was reloaded: ask for the camera again
  },

  result: async id => {
    const r = (await api("/api/results/" + id)).result;
    show(`<div class="card" style="text-align:center"><p class="mute">${esc(r.exam_title)}</p><div class="score" id="sc">0</div><p>out of ${r.total_marks} marks · ${r.percentage}%</p><span class="pill ${r.result_status}">${r.result_status}</span>
      <p>${r.correct_answers} correct · ${r.incorrect_answers} incorrect · ${r.unanswered_questions} unanswered</p><p class="mute">Completed ${new Date(r.completed_at).toLocaleString()}</p><a class="btn primary" href="#/dashboard">Dashboard</a> <a class="btn" href="#/history">All results</a></div>
      <h3>Review</h3><div class="review">${r.review.map((q, n) => `<div class="card" style="margin-bottom:1rem"><b>${n + 1}. ${esc(q.question_text)}</b>` + ["A","B","C","D"].map(L =>
        `<div class="opt ${L === q.correct ? "right" : L === q.selected ? "wrong" : ""}"><span><b>${L}.</b> ${esc(q["option_" + L.toLowerCase()])} ${L === q.correct ? "✔ correct" : ""}${L === q.selected && L !== q.correct ? "✘ your answer" : ""}</span></div>`).join("") +
        (q.selected ? "" : '<p class="mute">Not answered</p>') + (q.explanation ? `<p class="mute">${esc(q.explanation)}</p>` : "") + `</div>`).join("")}</div>`);
    const el = $("#sc"), end = +r.marks_obtained, t0 = performance.now();
    const step = t => { const p = Math.min(1, (t - t0) / 800); el.textContent = (end * p).toFixed(2).replace(/\.00$/, ""); if (p < 1) requestAnimationFrame(step); }; requestAnimationFrame(step);
  },

  history: async () => { const rs = (await api("/api/results")).results;
    show(`<h2>My results</h2><div class="card tablewrap"><table><tr><th>Exam</th><th>Score</th><th>%</th><th>Status</th><th>Date</th><th></th></tr>${rs.map(r =>
      `<tr><td>${esc(r.exam_title)}</td><td>${r.marks_obtained}/${r.total_marks}</td><td>${r.percentage}</td><td><span class="pill ${r.result_status}">${r.result_status}</span></td><td>${new Date(r.completed_at).toLocaleDateString()}</td><td><a href="#/result/${r.result_id}">View</a></td></tr>`).join("") || '<tr><td colspan="6">No results yet.</td></tr>'}</table></div>`); },

  profile: () => { show(`<form class="card" id="f"><h2>My profile</h2><p class="mute">${esc(me.email)} · ${me.role}</p><label for="pn">Full name</label><input id="pn" value="${esc(me.full_name)}" required minlength="2">
    <h3>Change password (optional)</h3><label for="cp">Current password</label><input id="cp" type="password" autocomplete="current-password"><label for="np">New password (8+ characters)</label><input id="np" type="password" minlength="8" autocomplete="new-password"><p><button class="primary">Save</button></p></form>`);
    $("#f").onsubmit = ev => { ev.preventDefault(); busy(ev.submitter, async () => { const d = await api("/api/auth/profile", "PUT", {full_name: $("#pn").value, current_password: $("#cp").value, new_password: $("#np").value});
      me.full_name = d.full_name; nav(); toast("Profile saved"); $("#cp").value = ""; $("#np").value = ""; }); }; },

  // ---------------- STAFF PAGES (teacher + admin) ----------------
  admin: async () => { const s = await api("/api/admin/stats"), tot = s.passed + s.failed;
    const cards = [["Students", s.students], ["Exams", s.exams], ["Attempts", s.attempts], ["Average", s.average + "%"], ["Proctoring warnings", s.violations]];
    if (me.role === "admin") cards.push(["Teachers", s.teachers], ["Awaiting approval", s.pending]);
    show(`<h2>${me.role === "admin" ? "Administrator" : "Teacher"} dashboard</h2><div class="grid">${cards.map(([k, v]) => `<div class="card stat"><b>${v}</b>${k}</div>`).join("")}</div>
      <div class="card" style="margin-top:1rem"><h3>Pass rate</h3><div class="bar"><i id="pb"></i></div><p class="mute">${s.passed} passed, ${s.failed} failed · Database: ${esc(s.db.backend)} (${s.db.ok ? "connected" : "problem"})</p>
      <a class="btn primary" href="#/admin/exams">Create or publish an exam</a></div>
      <h3>Recent results</h3><div class="card tablewrap"><table><tr><th>Score</th><th>%</th><th>Status</th><th>When</th></tr>${s.recent.map(r => `<tr><td>${r.marks_obtained}/${r.total_marks}</td><td>${r.percentage}</td><td><span class="pill ${r.result_status}">${r.result_status}</span></td><td>${new Date(r.completed_at).toLocaleString()}</td></tr>`).join("") || '<tr><td colspan="4">No results yet.</td></tr>'}</table></div>`);
    requestAnimationFrame(() => $("#pb").style.width = (tot ? s.passed / tot * 100 : 0) + "%"); },

  adminExams: async () => { const ex = (await api("/api/exams")).exams;
    show(`<h2>Exam papers</h2><form class="card" id="f" style="max-width:none;margin:0 0 1rem"><h3>New exam paper</h3><div class="grid"><div><label for="t">Title</label><input id="t" required></div><div><label for="s">Subject</label><input id="s"></div>
      <div><label for="d">Minutes</label><input id="d" type="number" min="1" value="30" required></div><div><label for="pp">Passing %</label><input id="pp" type="number" min="0" max="100" value="40" required></div>
      <div><label for="ng">Negative marks per wrong answer</label><input id="ng" type="number" min="0" step="0.05" value="0"></div></div><label for="ds">Description / instructions</label><textarea id="ds" rows="2"></textarea><p><button class="primary">Create draft, then add questions</button></p></form>
      <div class="card tablewrap"><table><tr><th>Title</th><th>Status</th><th>Questions</th><th>Actions</th></tr>${ex.map(e => `<tr><td>${esc(e.title)}</td><td><span class="pill ${e.status}">${e.status}</span></td><td>${e.total_questions}</td><td class="row">
      ${e.status === "draft" ? `<button data-edit="${e.exam_id}">Edit</button><a class="btn" href="#/admin/questions/${e.exam_id}">Questions</a><button class="primary" data-s="published" data-id="${e.exam_id}">Publish</button>` : ""}${e.status === "published" ? `<button data-s="draft" data-id="${e.exam_id}">Unpublish</button><button data-s="closed" data-id="${e.exam_id}">Close</button>` : ""}${e.status !== "archived" ? `<button data-s="archived" data-id="${e.exam_id}">Archive</button>` : ""}</td></tr>`).join("") || '<tr><td colspan="4">No exams yet. Create one above.</td></tr>'}</table></div>`);
    $("#f").onsubmit = ev => { ev.preventDefault(); busy(ev.submitter, async () => { const r = await api("/api/exams", "POST", {title: $("#t").value, subject: $("#s").value, description: $("#ds").value, duration_minutes: $("#d").value, passing_percentage: $("#pp").value, negative_marks: $("#ng").value}); toast("Draft created. Now add questions."); location.hash = "#/admin/questions/" + r.exam_id; }); };
    document.querySelectorAll("button[data-edit]").forEach(b => b.onclick = async () => { const e = ex.find(x => x.exam_id === b.dataset.edit);
      const html = `<h3>Edit exam</h3><label for="et">Title</label><input id="et" value="${esc(e.title)}"><label for="es">Subject</label><input id="es" value="${esc(e.subject)}"><label for="ed">Minutes</label><input id="ed" type="number" min="1" value="${esc(e.duration_minutes)}">
        <label for="ep">Passing %</label><input id="ep" type="number" min="0" max="100" value="${esc(e.passing_percentage)}"><label for="en">Negative marks per wrong answer</label><input id="en" type="number" min="0" step="0.05" value="${esc(e.negative_marks_per_wrong_answer)}"><label for="ex2">Description</label><textarea id="ex2" rows="2">${esc(e.description)}</textarea>`;
      if (await confirmDlg(html, "Save")) busy(b, async () => { await api(`/api/exams/${e.exam_id}`, "PUT", {title: $("#et").value, subject: $("#es").value, duration_minutes: $("#ed").value, passing_percentage: $("#ep").value, negative_marks: $("#en").value, description: $("#ex2").value}); toast("Saved"); route(); }); });
    document.querySelectorAll("button[data-s]").forEach(b => b.onclick = () => busy(b, async () => { await api(`/api/exams/${b.dataset.id}/status`, "POST", {status: b.dataset.s}); toast(b.dataset.s === "published" ? "Published. Students can now see it." : "Updated"); route(); })); },

  adminQuestions: async id => { const r = await api(`/api/exams/${id}/questions`), qs = r.questions, draft = r.exam.status === "draft";
    show(`<a href="#/admin/exams">← Exams</a><h2>${esc(r.exam.title)} · questions (${qs.length})</h2>${draft ? `<form class="card" id="f" style="max-width:none;margin:0 0 1rem"><label for="qt">Question</label><textarea id="qt" required rows="2"></textarea>
      <div class="grid">${"abcd".split("").map(c => `<div><label for="o${c}">Option ${c.toUpperCase()}</label><input id="o${c}" required></div>`).join("")}</div><div class="grid"><div><label for="co">Correct option</label><select id="co"><option>A</option><option>B</option><option>C</option><option>D</option></select></div>
      <div><label for="mk">Marks</label><input id="mk" type="number" min="0.25" step="0.25" value="1"></div></div><label for="ex">Explanation (optional)</label><input id="ex"><p><button class="primary">Add question</button></p></form>` : '<p class="mute">This exam is not a draft, so questions are locked.</p>'}
      ${qs.map(q => `<div class="card row" style="margin-bottom:.6rem;justify-content:space-between"><span>${q.question_order}. ${esc(q.question_text)} <span class="mute">(answer ${q.correct_option})</span></span>${draft ? `<span class="row"><button data-eq="${q.question_id}">Edit</button><button class="danger" data-q="${q.question_id}">Delete</button></span>` : ""}</div>`).join("")}
      ${draft && qs.length ? `<p><button class="primary" id="pub">Publish exam for students</button></p>` : ""}`);
    if (draft) $("#f").onsubmit = ev => { ev.preventDefault(); busy(ev.submitter, async () => { await api(`/api/exams/${id}/questions`, "POST", {question_text: $("#qt").value, option_a: $("#oa").value, option_b: $("#ob").value, option_c: $("#oc").value, option_d: $("#od").value, correct_option: $("#co").value, marks: $("#mk").value, explanation: $("#ex").value}); toast("Question added"); route(); }); };
    if ($("#pub")) $("#pub").onclick = ev => busy(ev.target, async () => { await api(`/api/exams/${id}/status`, "POST", {status: "published"}); toast("Published!"); location.hash = "#/admin/exams"; });
    document.querySelectorAll("button[data-q]").forEach(b => b.onclick = () => busy(b, async () => { await api("/api/questions/" + b.dataset.q, "DELETE"); route(); }));
    document.querySelectorAll("button[data-eq]").forEach(b => b.onclick = async () => { const x = qs.find(z => z.question_id === b.dataset.eq);
      const html = `<h3>Edit question</h3><label for="q_text">Question</label><textarea id="q_text" rows="2">${esc(x.question_text)}</textarea>` + "abcd".split("").map(c => `<label for="q_${c}">Option ${c.toUpperCase()}</label><input id="q_${c}" value="${esc(x["option_" + c])}">`).join("") +
        `<label for="q_ok">Correct option</label><select id="q_ok">${"ABCD".split("").map(L => `<option ${L === x.correct_option ? "selected" : ""}>${L}</option>`).join("")}</select><label for="q_marks">Marks</label><input id="q_marks" type="number" min="0.25" step="0.25" value="${esc(x.marks)}"><label for="q_exp">Explanation</label><input id="q_exp" value="${esc(x.explanation)}">`;
      if (await confirmDlg(html, "Save")) busy(b, async () => { await api("/api/questions/" + x.question_id, "PUT", {question_text: $("#q_text").value, option_a: $("#q_a").value, option_b: $("#q_b").value, option_c: $("#q_c").value, option_d: $("#q_d").value, correct_option: $("#q_ok").value, marks: $("#q_marks").value, explanation: $("#q_exp").value}); toast("Saved"); route(); }); }); },

  adminResults: async () => { const ex = (await api("/api/exams")).exams, q = new URLSearchParams(location.hash.split("?")[1] || ""), r = await api("/api/admin/results?" + q);
    show(`<h2>Results (${r.total})</h2><div class="row"><select id="fe" aria-label="Exam"><option value="">All exams</option>${ex.map(e => `<option value="${e.exam_id}" ${q.get("exam_id") === e.exam_id ? "selected" : ""}>${esc(e.title)}</option>`).join("")}</select>
      <select id="fs" aria-label="Status"><option value="">Pass and fail</option><option ${q.get("status") === "PASS" ? "selected" : ""}>PASS</option><option ${q.get("status") === "FAIL" ? "selected" : ""}>FAIL</option></select>
      <input id="fq" placeholder="Search student" aria-label="Search student" value="${esc(q.get("q") || "")}" style="width:auto"><input id="fd1" type="date" aria-label="From date" value="${esc(q.get("date_from") || "")}" style="width:auto"><input id="fd2" type="date" aria-label="To date" value="${esc(q.get("date_to") || "")}" style="width:auto"><button id="ap">Filter</button><button id="csv">Export CSV</button></div>
      <div class="card tablewrap" style="margin-top:1rem"><table><tr><th>Student</th><th>Exam</th><th>Score</th><th>%</th><th>Status</th><th>Warnings</th><th>Date</th></tr>${r.results.map(x => `<tr><td>${esc(x.student)}</td><td>${esc(x.exam_title)}</td><td>${x.marks_obtained}/${x.total_marks}</td><td>${x.percentage}</td><td><span class="pill ${x.result_status}">${x.result_status}</span></td><td>${x.violations}</td><td>${new Date(x.completed_at).toLocaleString()}</td></tr>`).join("") || '<tr><td colspan="7">No results.</td></tr>'}</table></div>`);
    const qs = () => new URLSearchParams({exam_id: $("#fe").value, status: $("#fs").value, q: $("#fq").value, date_from: $("#fd1").value, date_to: $("#fd2").value});
    $("#ap").onclick = () => location.hash = "#/admin/results?" + qs();
    $("#csv").onclick = () => busy($("#csv"), async () => { const res = await api("/api/admin/results/export?" + qs()); const a = document.createElement("a"); a.href = URL.createObjectURL(await res.blob()); a.download = "results.csv"; a.click(); }); },

  adminProctoring: async () => { const v = (await api("/api/staff/violations")).violations;
    show(`<h2>Proctoring log</h2><p class="mute">Tab switches, window changes and camera-off events reported during exams.</p><div class="card tablewrap"><table><tr><th>Time</th><th>Student</th><th>Exam</th><th>Event</th></tr>${v.map(x => `<tr><td>${new Date(x.timestamp).toLocaleString()}</td><td>${esc(x.student)}</td><td>${esc(x.exam_title)}</td><td>${esc(x.type.replace("_", " "))}</td></tr>`).join("") || '<tr><td colspan="4">No events recorded.</td></tr>'}</table></div>`); },

  // ---------------- ADMIN-ONLY PAGES ----------------
  adminStudents: async () => { const us = (await api("/api/admin/users")).users;
    show(`<h2>Users</h2><div class="card tablewrap"><table><tr><th>Name</th><th>Email</th><th>Role</th><th>Status</th><th></th></tr>${us.map(u => `<tr><td>${esc(u.full_name)}</td><td>${esc(u.email)}</td><td>${u.role}</td><td><span class="pill ${u.status}">${u.status}</span></td><td>${u.user_id === me.user_id || u.role === "admin" ? "" :
      u.status === "pending" ? `<button class="primary" data-u="${u.user_id}" data-s="active">Approve</button>` : `<button data-u="${u.user_id}" data-s="${u.status === "active" ? "inactive" : "active"}">${u.status === "active" ? "Deactivate" : "Activate"}</button>`}</td></tr>`).join("")}</table></div>`);
    document.querySelectorAll("button[data-u]").forEach(b => b.onclick = () => busy(b, async () => { await api(`/api/admin/users/${b.dataset.u}/status`, "POST", {status: b.dataset.s}); route(); })); },

  adminAudit: async () => { const l = (await api("/api/admin/audit")).logs;
    show(`<h2>Audit log (latest 100)</h2><div class="card tablewrap"><table><tr><th>Time</th><th>Action</th><th>Entity</th><th>Status</th><th>Details</th></tr>${l.map(x => `<tr><td>${new Date(x.timestamp).toLocaleString()}</td><td>${esc(x.action)}</td><td>${esc(x.entity_type)} ${esc(x.entity_id)}</td><td>${esc(x.status)}</td><td>${esc(x.details)}</td></tr>`).join("")}</table></div>`); },
};

// =====================================================================
//  ROUTER
// =====================================================================
async function route() {
  const [path] = (location.hash.slice(1) || "/").split("?"), p = path.split("/").filter(Boolean);
  try {
    if (me === null) { const d = await api("/api/auth/me"); if (d.user) { me = d.user; csrf = d.csrf; } }
    nav();
    /** Send the person somewhere sensible if they are not allowed on this page. */
    const need = role => {
      if (!me) { location.hash = "#/login"; return false; }
      const ok = !role || (role === "staff" ? isStaff() : me.role === role);
      if (!ok) { location.hash = me.role === "student" ? "#/dashboard" : "#/admin"; return false; }
      return true; };
    const [a, b] = p;
    if (!a) return views.home();
    const pub = {features: views.features, "how-it-works": views.howitworks, faq: views.faq, about: views.about, contact: views.contact};
    if (pub[a]) return pub[a]();
    if (a === "login" || a === "register") return me ? (location.hash = me.role === "student" ? "#/dashboard" : "#/admin") : views[a]();
    if (a === "profile") { if (!need()) return; return views.profile(); }
    if (a === "admin") {
      if (b === "students" || b === "audit") { if (!need("admin")) return; return b === "students" ? views.adminStudents() : views.adminAudit(); }
      if (!need("staff")) return;
      return b === "exams" ? views.adminExams() : b === "questions" ? views.adminQuestions(p[2]) : b === "results" ? views.adminResults() : b === "proctoring" ? views.adminProctoring() : views.admin();
    }
    if (!need("student")) return;
    if (a === "dashboard") return views.dashboard(); if (a === "history") return views.history();
    if (a === "exam") return views.instructions(b); if (a === "take") return views.take(b); if (a === "result") return views.result(b);
    views.home();
  } catch (e) { show(`<div class="card"><h3>Something went wrong</h3><p>${esc(e.message)}</p></div>`); }
}
window.addEventListener("hashchange", route);
route();
