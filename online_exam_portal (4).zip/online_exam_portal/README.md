# ExamDesk – Online MCQ Examination Portal

Flask + vanilla JS + Google Sheets. Server-side scoring, server-owned timer, instant results.

## 0. Easiest start (Windows)
Double-click **run.bat**. It creates the environment, installs packages and starts the app.
Then open the address printed in the window (normally http://127.0.0.1:5000).
Admin login (local mode): `admin@example.com` / `Admin@12345` (change in `.env`). Data is saved in `data/local_db.json`.

## 1. Run from VS Code terminal
1. **File > Open Folder** > choose `online_exam_portal` (the folder containing `app.py`).
2. **Terminal > New Terminal**, then:
```
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
Copy-Item .env.example .env
python app.py
```
If activation is blocked: `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass`.
The app picks the next free port (5000 to 5010) and prints the exact address.

Google Sheets is optional: set `STORAGE=google` and follow section 2.

## Login types and demo accounts (local mode)
| Role | Email | Password | Can do |
|---|---|---|---|
| Admin | admin@example.com | Admin@12345 | everything, approve teachers, audit log |
| Teacher | teacher@example.com | Teacher@12345 | create/publish own exams, see own results |
| Student | student@example.com | Student@12345 | take exams (a sample exam is included) |

Teachers who register themselves stay *pending* until an admin approves them (Admin > Users).

## Proctoring
- The student must turn on the **camera** before starting and keep it on. If it stops, the exam is blocked until it is turned back on and a warning is logged.
- Switching tabs or windows shows a warning and is logged. After `MAX_VIOLATIONS` (default 3) the exam is submitted automatically.
- Video stays in the browser. It is **not** recorded or uploaded.
- Use Chrome or Edge and open `http://127.0.0.1:5000` (cameras only work on localhost or HTTPS).
- Limit: browser checks discourage cheating but cannot make it impossible. Do not rely on them alone for high-stakes exams.

## Something not working?
Run `python doctor.py`. It checks Python, packages, files, `.env` and the database and tells you what to fix.
Open `http://127.0.0.1:5000/api/health` to confirm the app and database are alive.
**Always extract the ZIP into a NEW empty folder** - mixing files from an older version causes errors like `SheetsDB`.

## 2. Google Cloud and Sheets setup
1. Go to console.cloud.google.com, create or select a project.
2. **APIs & Services > Library**: enable **Google Sheets API**.
3. **IAM & Admin > Service Accounts > Create**. Open it, **Keys > Add key > JSON**; save the file as `credentials/service_account.json`.
   If your organisation blocks key creation, ask your admin for an allowed alternative (e.g. workload identity); do not bypass the policy.
4. Create a blank Google Sheet. Copy the ID from its URL (`/d/<ID>/edit`) into `GOOGLE_SHEET_ID`.
5. Click **Share**, paste the service account email (`...@...iam.gserviceaccount.com`), give **Editor** access.
6. `python check_connection.py` creates the 7 worksheets with headers and tests a write and delete.

Never commit `.env` or `credentials/*.json` (already in `.gitignore`).

## 3. Settings (`.env`)
| Name | Meaning |
|---|---|
| FLASK_SECRET_KEY | Random secret for sessions. Generate: `python -c "import secrets;print(secrets.token_hex(32))"` |
| GOOGLE_SHEET_ID | Spreadsheet ID |
| GOOGLE_APPLICATION_CREDENTIALS | Path to service-account JSON |
| DEMO_MODE | `true` = in-memory storage, development/testing only. Never auto-enabled after a failure |
| FLASK_DEBUG | `true` only while developing |
| COOKIE_SECURE | `true` when served over HTTPS |

## 4. Start and first use
1. Local mode: an admin is created automatically. Google mode: run `python create_admin.py`.
2. `python app.py`, open http://127.0.0.1:5000
3. Log in as admin, **Exams** > create a draft > **Questions** > add MCQs > **Publish**.
4. Register a student in another browser/private window, start the exam, submit. The result shows immediately and appears in the Results and Responses sheets.

## 5. Tests
`python -m pytest -q tests` (set `DEMO_MODE=true`). Uses in-memory storage, no Google account needed.

## 6. Troubleshooting
- **Credentials file not found**: check the path in `.env`.
- **Spreadsheet not found / permission**: share the sheet with the service account email as Editor.
- **API error 429**: Sheets quota (about 60 writes per minute per user). Retries with backoff are built in; many simultaneous submissions can still be slow.
- **Unexpected columns**: do not rename headers in the generated worksheets.
- **Activate.ps1 blocked**: see step 1.5.

## 7. Limits
Google Sheets has no transactions or unique constraints. Duplicate submission is prevented by checking for an existing Result per attempt, but two truly simultaneous requests could race. Use PostgreSQL for high-stakes or large exams. Run with one server process.
