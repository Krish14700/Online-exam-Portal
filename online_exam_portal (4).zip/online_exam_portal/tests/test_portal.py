import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
import pytest
from datetime import datetime, timezone, timedelta
from werkzeug.security import generate_password_hash
from app import create_app
from services.store import MemoryStore
from services.scoring_service import score_attempt

QS = [{"question_id": str(i), "correct_option": "A", "marks": 1} for i in range(20)]

def test_spec_example():
    ans = {str(i): "A" for i in range(12)}; ans.update({str(i): "B" for i in range(12, 15)})
    r = score_attempt(QS, ans, True, 0.25, 40)
    assert (r["correct"], r["incorrect"], r["unanswered"]) == (12, 3, 5)
    assert r["marks_obtained"] == 11.25 and r["percentage"] == 56.25 and r["result_status"] == "PASS"

def test_no_negative_and_fail_and_zero_total():
    assert score_attempt(QS, {"0": "B"}, False, 1, 40)["marks_obtained"] == 0
    assert score_attempt(QS, {"0": "A"}, False, 0, 40)["result_status"] == "FAIL"
    assert score_attempt([], {}, False, 0, 40)["percentage"] == 0

@pytest.fixture
def env():
    store = MemoryStore()
    store.add("Users", {"user_id": "adm", "full_name": "Admin", "email": "a@x.com", "password_hash": generate_password_hash("adminpass1"),
                        "role": "admin", "status": "active"})
    app = create_app(store); app.testing = True
    return app, store

def client(app, email, pw):
    c = app.test_client(); r = c.post("/api/auth/login", json={"email": email, "password": pw})
    return c, ({"X-CSRF-Token": r.get_json()["csrf"]} if r.status_code == 200 else None), r

def setup_exam(app):
    c, h, _ = client(app, "a@x.com", "adminpass1")
    eid = c.post("/api/exams", json={"title": "T", "duration_minutes": 10, "passing_percentage": 50, "negative_marks": 0.5}, headers=h).get_json()["exam_id"]
    for i in range(2):
        c.post(f"/api/exams/{eid}/questions", json={"question_text": f"Q{i}", "option_a": "1", "option_b": "2", "option_c": "3",
               "option_d": "4", "correct_option": "A", "marks": 1, "explanation": "because"}, headers=h)
    assert c.post(f"/api/exams/{eid}/status", json={"status": "published"}, headers=h).status_code == 200
    return eid

def student(app, email="s@x.com"):
    c = app.test_client()
    assert c.post("/api/auth/register", json={"full_name": "Stu", "email": email, "password": "password1"}).status_code == 201
    return client(app, email, "password1")

def test_register_duplicate_and_hash(env):
    app, store = env; student(app)
    assert app.test_client().post("/api/auth/register", json={"full_name": "Sam", "email": "S@x.com", "password": "password1"}).status_code == 409
    u = [x for x in store.all("Users") if x["email"] == "s@x.com"][0]
    assert u["role"] == "student" and u["password_hash"] != "password1"

def test_bad_login_generic(env):
    app, _ = env
    assert client(app, "nobody@x.com", "whatever12")[2].status_code == 401

def test_student_cannot_use_admin(env):
    app, _ = env; c, h, _ = student(app)
    assert c.get("/api/admin/stats").status_code == 403
    assert c.post("/api/exams", json={}, headers=h).status_code == 403

def test_csrf_required(env):
    app, _ = env; c, h, _ = client(app, "a@x.com", "adminpass1")
    assert c.post("/api/exams", json={"title": "x"}).status_code == 403

def test_full_flow_and_no_key_leak(env):
    app, store = env; eid = setup_exam(app); c, h, _ = student(app)
    aid = c.post(f"/api/exams/{eid}/attempts", headers=h).get_json()["attempt_id"]
    data = c.get(f"/api/attempts/{aid}").get_json()
    assert "correct_option" not in str(data) and "because" not in str(data)
    q1, q2 = [q["question_id"] for q in data["questions"]]
    c.put(f"/api/attempts/{aid}/responses", json={"question_id": q1, "selected_option": "A"}, headers=h)
    c.put(f"/api/attempts/{aid}/responses", json={"question_id": q2, "selected_option": "B"}, headers=h)
    r1 = c.post(f"/api/attempts/{aid}/submit", headers=h).get_json()["result"]
    r2 = c.post(f"/api/attempts/{aid}/submit", headers=h).get_json()["result"]
    assert r1["marks_obtained"] == 0.5 and r1["result_id"] == r2["result_id"]
    assert len(store.all("Results")) == 1
    assert c.put(f"/api/attempts/{aid}/responses", json={"question_id": q1, "selected_option": "B"}, headers=h).status_code == 409
    assert c.post(f"/api/exams/{eid}/attempts", headers=h).status_code == 409

def test_attempt_ownership(env):
    app, _ = env; eid = setup_exam(app); c1, h1, _ = student(app); c2, h2, _ = student(app, "t@x.com")
    aid = c1.post(f"/api/exams/{eid}/attempts", headers=h1).get_json()["attempt_id"]
    assert c2.get(f"/api/attempts/{aid}").status_code == 404
    assert c2.post(f"/api/attempts/{aid}/submit", headers=h2).status_code == 404

def test_expiry_auto_submits(env):
    app, store = env; eid = setup_exam(app); c, h, _ = student(app)
    aid = c.post(f"/api/exams/{eid}/attempts", headers=h).get_json()["attempt_id"]
    store.update("Attempts", "attempt_id", aid, {"expires_at": (datetime.now(timezone.utc) - timedelta(seconds=5)).isoformat()})
    assert c.get(f"/api/attempts/{aid}").status_code == 410
    assert len(store.all("Results")) == 1

def test_unpublished_blocked_and_publish_needs_questions(env):
    app, _ = env; c, h, _ = client(app, "a@x.com", "adminpass1")
    eid = c.post("/api/exams", json={"title": "E", "duration_minutes": 5, "passing_percentage": 40}, headers=h).get_json()["exam_id"]
    assert c.post(f"/api/exams/{eid}/status", json={"status": "published"}, headers=h).status_code == 400
    s, sh, _ = student(app)
    assert s.post(f"/api/exams/{eid}/attempts", headers=sh).status_code == 404

def test_missing_credentials_message():
    from services.store import SheetsStore, StoreError
    with pytest.raises(StoreError, match="Credentials file not found"):
        SheetsStore("id", "credentials/nope.json")


# ---------------- extra tests for the bug fixes ----------------
def test_expired_unsubmitted_attempt_cannot_be_restarted(env):
    app, store = env; eid = setup_exam(app); c, h, _ = student(app)
    aid = c.post(f"/api/exams/{eid}/attempts", headers=h).get_json()["attempt_id"]
    store.update("Attempts", "attempt_id", aid, {"expires_at": (datetime.now(timezone.utc) - timedelta(seconds=5)).isoformat()})
    assert c.post(f"/api/exams/{eid}/attempts", headers=h).status_code == 409   # no free retake
    assert len(store.all("Results")) == 1

def test_edit_exam_and_question_only_in_draft(env):
    app, store = env; c, h, _ = client(app, "a@x.com", "adminpass1")
    eid = c.post("/api/exams", json={"title": "E", "duration_minutes": 5, "passing_percentage": 40}, headers=h).get_json()["exam_id"]
    assert c.put(f"/api/exams/{eid}", json={"title": "New", "duration_minutes": 9, "passing_percentage": 50}, headers=h).status_code == 200
    c.post(f"/api/exams/{eid}/questions", json={"question_text": "Q", "option_a": "1", "option_b": "2", "option_c": "3", "option_d": "4", "correct_option": "B"}, headers=h)
    qid = store.all("Questions")[0]["question_id"]
    assert c.put(f"/api/questions/{qid}", json={"question_text": "Q2", "option_a": "1", "option_b": "2", "option_c": "3", "option_d": "4", "correct_option": "C", "marks": 2}, headers=h).status_code == 200
    assert store.all("Questions")[0]["correct_option"] == "C" and float(store.all("Exams")[0]["total_marks"]) == 2
    c.post(f"/api/exams/{eid}/status", json={"status": "published"}, headers=h)
    assert c.put(f"/api/exams/{eid}", json={"title": "x", "duration_minutes": 9, "passing_percentage": 50}, headers=h).status_code == 409

def test_cannot_return_to_draft_after_attempts(env):
    app, _ = env; eid = setup_exam(app); s, sh, _ = student(app)
    s.post(f"/api/exams/{eid}/attempts", headers=sh)
    a, ah, _ = client(app, "a@x.com", "adminpass1")
    assert a.post(f"/api/exams/{eid}/status", json={"status": "draft"}, headers=ah).status_code == 409

def test_profile_password_change(env):
    app, _ = env; c, h, _ = student(app)
    assert c.put("/api/auth/profile", json={"full_name": "Stu", "new_password": "newpassword1", "current_password": "wrong"}, headers=h).status_code == 403
    assert c.put("/api/auth/profile", json={"full_name": "Stu Two", "new_password": "newpassword1", "current_password": "password1"}, headers=h).status_code == 200
    assert client(app, "s@x.com", "newpassword1")[2].status_code == 200

def test_csv_export_guards_formulas(env):
    app, store = env; eid = setup_exam(app); c, h, _ = student(app)
    aid = c.post(f"/api/exams/{eid}/attempts", headers=h).get_json()["attempt_id"]; c.post(f"/api/attempts/{aid}/submit", headers=h)
    store.update("Users", "email", "s@x.com", {"full_name": "=HYPERLINK(1)"})
    a, ah, _ = client(app, "a@x.com", "adminpass1")
    body = a.get("/api/admin/results/export").data.decode("utf-8")
    assert "'=HYPERLINK(1)" in body

def test_file_store_persists_between_runs():
    import tempfile, pathlib
    from services.store import FileStore
    path = pathlib.Path(tempfile.mkdtemp()) / "db.json"
    FileStore(path).add("Users", {"user_id": "u1", "email": "z@x.com"})
    assert FileStore(path).all("Users")[0]["email"] == "z@x.com"

def test_health_endpoint(env):
    app, _ = env
    assert app.test_client().get("/api/health").get_json()["ok"] is True


# ---------------- teacher role + proctoring tests ----------------
def make_teacher(app, admin_c, admin_h, email="t@x.com"):
    c = app.test_client()
    r = c.post("/api/auth/register", json={"full_name": "Teach", "email": email, "password": "password1", "role": "teacher"})
    assert r.status_code == 201
    return c

def test_teacher_pending_until_approved_and_role_tab_checked(env):
    app, store = env; ac, ah, _ = client(app, "a@x.com", "adminpass1"); make_teacher(app, ac, ah)
    assert client(app, "t@x.com", "password1")[2].status_code == 403           # pending
    tid = [u for u in store.all("Users") if u["email"] == "t@x.com"][0]["user_id"]
    assert ac.post(f"/api/admin/users/{tid}/status", json={"status": "active"}, headers=ah).status_code == 200
    c = app.test_client()
    assert c.post("/api/auth/login", json={"email": "t@x.com", "password": "password1", "role": "admin"}).status_code == 403  # wrong tab
    assert c.post("/api/auth/login", json={"email": "t@x.com", "password": "password1", "role": "teacher"}).status_code == 200

def test_register_cannot_create_admin(env):
    app, store = env
    app.test_client().post("/api/auth/register", json={"full_name": "Evil", "email": "e@x.com", "password": "password1", "role": "admin"})
    assert [u for u in store.all("Users") if u["email"] == "e@x.com"][0]["role"] == "student"

def test_teacher_only_manages_own_exams(env):
    app, store = env; ac, ah, _ = client(app, "a@x.com", "adminpass1"); make_teacher(app, ac, ah)
    store.update("Users", "email", "t@x.com", {"status": "active"})
    tc, th, _ = client(app, "t@x.com", "password1")
    admin_exam = setup_exam(app)                                                # created by admin
    mine = tc.post("/api/exams", json={"title": "Mine", "duration_minutes": 5, "passing_percentage": 40}, headers=th).get_json()["exam_id"]
    ids = [e["exam_id"] for e in tc.get("/api/exams").get_json()["exams"]]
    assert ids == [mine]
    assert tc.get(f"/api/exams/{admin_exam}/questions").status_code == 403
    assert tc.get("/api/admin/audit").status_code == 403                        # admin-only page

def test_violations_auto_submit_at_limit(env):
    app, store = env; eid = setup_exam(app); c, h, _ = student(app)
    aid = c.post(f"/api/exams/{eid}/attempts", headers=h).get_json()["attempt_id"]
    import config
    for i in range(config.MAX_VIOLATIONS):
        # make previous violation old enough to bypass the 2-second de-duplication
        for v in store.all("Violations"):
            store.update("Violations", "violation_id", v["violation_id"], {"timestamp": "2020-01-01T00:00:00+00:00"})
        r = c.post(f"/api/attempts/{aid}/violations", json={"type": "tab_switch"}, headers=h).get_json()
    assert r["auto_submitted"] is True and len(store.all("Results")) == 1
    assert c.post(f"/api/attempts/{aid}/violations", json={"type": "tab_switch"}, headers=h).status_code == 409

def test_violation_validation_and_ownership(env):
    app, _ = env; eid = setup_exam(app); c1, h1, _ = student(app); c2, h2, _ = student(app, "u@x.com")
    aid = c1.post(f"/api/exams/{eid}/attempts", headers=h1).get_json()["attempt_id"]
    assert c1.post(f"/api/attempts/{aid}/violations", json={"type": "nonsense"}, headers=h1).status_code == 400
    assert c2.post(f"/api/attempts/{aid}/violations", json={"type": "tab_switch"}, headers=h2).status_code == 404

def test_contact_form(env):
    app, _ = env
    assert app.test_client().post("/api/contact", json={"name": "Sam", "email": "s@x.com", "message": "Hello there"}).status_code == 201
    assert app.test_client().post("/api/contact", json={"name": "", "email": "bad", "message": ""}).status_code == 400

def test_demo_seed_creates_playable_exam():
    from app import seed_demo
    store = MemoryStore(); seed_demo(store)
    assert len(store.all("Exams")) == 1 and len(store.all("Questions")) == 5
