"""
ExamDesk - Online MCQ Examination Portal (Flask backend)
=========================================================

HOW THIS FILE IS ORGANISED
  1. Imports and small helper functions
  2. create_app()  -> builds the Flask application
       a. configuration + database connection
       b. security helpers (login check, CSRF, role check)
       c. validation helpers
       d. page route, auth routes
       e. exam + question routes (admin)
       f. attempt routes (student takes the exam)
       g. result routes (student + admin)
       h. admin statistics + user management
  3. Start-up block (python app.py)

SECURITY RULES FOLLOWED
  * Scores, roles, deadlines and answer keys are NEVER trusted from the browser.
  * Students never receive correct answers until their attempt is submitted.
  * Every state-changing request needs the CSRF token the server issued at login.
"""

import csv
import io
import logging
import secrets
import threading
import uuid
from datetime import datetime, timedelta, timezone
from functools import wraps

from flask import Flask, Response, jsonify, render_template, request, session
from werkzeug.security import check_password_hash, generate_password_hash

import config
from services.scoring_service import score_attempt
from services.store import StoreError, build_store, now_iso

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("app")


# ---------------------------------------------------------------------------
# 1. SMALL HELPERS (pure functions, no Flask state)
# ---------------------------------------------------------------------------
def uid(prefix):
    """Create a unique id such as 'usr_3fa91c02b7de'."""
    return f"{prefix}_{uuid.uuid4().hex[:12]}"


def parse(ts):
    """Turn an ISO timestamp string into an aware datetime (UTC if no zone given).

    Older versions crashed when a timestamp had no timezone; treating it as UTC fixes that.
    """
    dt = datetime.fromisoformat(str(ts))
    return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)


def err(message, code=400):
    """Standard JSON error response."""
    return jsonify({"ok": False, "error": message}), code


def ok(**data):
    """Standard JSON success response."""
    return jsonify({"ok": True, **data})


def truthy(value):
    """Google Sheets and files store booleans as text; this reads them safely."""
    return str(value).strip().lower() == "true"


def to_float(value, default=0.0):
    """Convert to float without crashing on blank cells."""
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


# One process-wide lock. The Flask dev server handles requests in several threads,
# so two clicks at the same moment could otherwise both pass an "already submitted?" check.
WRITE_LOCK = threading.RLock()


def seed_admin(db):
    """LOCAL / MEMORY storage only: make sure an admin exists so the app works out of the box.

    For Google storage run `python create_admin.py` instead (no default password is ever created there).
    """
    if any(u["role"] == "admin" for u in db.all("Users")):
        return
    stamp = now_iso()
    db.add("Users", {
        "user_id": uid("usr"), "full_name": "Administrator", "email": config.ADMIN_EMAIL,
        "password_hash": generate_password_hash(config.ADMIN_PASSWORD),
        "role": "admin", "status": "active", "created_at": stamp, "updated_at": stamp,
    })


def seed_demo(db):
    """LOCAL / MEMORY storage only: a demo teacher, a demo student and one ready-to-take exam.

    This lets you click through every page immediately. Turn it off with SEED_DEMO=false in .env.
    """
    if any(u["email"] == "teacher@example.com" for u in db.all("Users")):
        return
    stamp = now_iso()
    teacher_id = uid("usr")
    for uid_, name, email, pw, role in ((teacher_id, "Demo Teacher", "teacher@example.com", "Teacher@12345", "teacher"),
                                        (uid("usr"), "Demo Student", "student@example.com", "Student@12345", "student")):
        db.add("Users", {"user_id": uid_, "full_name": name, "email": email, "password_hash": generate_password_hash(pw),
                         "role": role, "status": "active", "created_at": stamp, "updated_at": stamp})
    exam_id = uid("exm")
    sample = [("Which language runs in a web browser?", "Python", "JavaScript", "C", "Java", "B", "JavaScript is built into browsers."),
              ("What does HTML stand for?", "HyperText Markup Language", "High Tech Modern Language", "Home Tool Markup Language", "Hyperlinks Text Mode Language", "A", ""),
              ("Which tag makes the largest heading?", "<h6>", "<head>", "<h1>", "<heading>", "C", ""),
              ("What does CSS style?", "Databases", "Web page appearance", "Servers", "Emails", "B", ""),
              ("Which symbol starts a CSS id selector?", ".", "#", "@", "&", "B", "Classes use a dot; ids use #.")]
    db.add("Exams", {"exam_id": exam_id, "title": "Sample: Web Basics Quiz", "description": "A short demo exam with 5 questions.",
                     "subject": "Web Development", "duration_minutes": 10, "total_questions": len(sample), "total_marks": len(sample),
                     "passing_percentage": 40, "negative_marking_enabled": "true", "negative_marks_per_wrong_answer": 0.25,
                     "start_datetime": "", "end_datetime": "", "status": "published", "created_by": teacher_id,
                     "created_at": stamp, "updated_at": stamp})
    for n, (text, a, b, c_, d, ans, why) in enumerate(sample, start=1):
        db.add("Questions", {"question_id": uid("q"), "exam_id": exam_id, "question_text": text, "option_a": a, "option_b": b,
                             "option_c": c_, "option_d": d, "correct_option": ans, "marks": 1, "explanation": why,
                             "question_order": n, "created_at": stamp, "updated_at": stamp})


# ---------------------------------------------------------------------------
# 2. APPLICATION FACTORY
# ---------------------------------------------------------------------------
def create_app(store=None):
    """Build the Flask app. `store` is only passed in by the tests."""
    app = Flask(__name__)
    app.secret_key = config.get_secret()
    app.config.update(
        SESSION_COOKIE_HTTPONLY=True,          # JavaScript cannot read the session cookie
        SESSION_COOKIE_SAMESITE="Lax",         # basic CSRF protection by the browser
        SESSION_COOKIE_SECURE=config.COOKIE_SECURE,
        PERMANENT_SESSION_LIFETIME=timedelta(hours=8),
        MAX_CONTENT_LENGTH=256 * 1024,         # reject huge request bodies
    )

    # ---- a. database connection -------------------------------------------------
    try:
        db = store or build_store(config)
    except StoreError as exc:
        # A readable one-line message instead of a long traceback.
        raise SystemExit(f"\nDATABASE ERROR: {exc}\n")
    app.db = db
    if store is None and config.STORAGE in ("local", "memory"):
        seed_admin(db)
        if config.SEED_DEMO:
            seed_demo(db)

    failed_logins = {}  # ip -> list of timestamps (simple in-memory rate limit)

    # ---- b. security + generic helpers ------------------------------------------
    def audit(action, etype="", eid="", status="ok", details=""):
        """Write an audit-log row. Never lets a logging failure break the request."""
        try:
            db.add("AuditLogs", {
                "log_id": uid("log"), "actor_user_id": session.get("uid", ""), "action": action,
                "entity_type": etype, "entity_id": eid, "timestamp": now_iso(),
                "status": status, "details": str(details)[:200],   # never put secrets in details
            })
        except StoreError:
            log.warning("audit write failed for action=%s", action)

    def find(sheet, key, value):
        """Return the first row where row[key] == value, else None."""
        return next((r for r in db.all(sheet) if str(r.get(key, "")) == str(value)), None)

    def current_user():
        """The logged-in, active user, or None."""
        if "uid" not in session:
            return None
        user = find("Users", "user_id", session["uid"])
        return user if user and user["status"] == "active" else None

    def auth(role=None):
        """Decorator: require login, optionally a role, and a CSRF token on writes."""
        def decorator(view):
            @wraps(view)
            def wrapper(*args, **kwargs):
                user = current_user()
                if not user:
                    return err("Please log in.", 401)
                # "staff" means admin OR teacher; anything else is one exact role.
                allowed = ("admin", "teacher") if role == "staff" else (role,)
                if role and user["role"] not in allowed:
                    return err("You do not have access to this.", 403)
                if request.method in ("POST", "PUT", "DELETE") and \
                        request.headers.get("X-CSRF-Token") != session.get("csrf"):
                    return err("Security token invalid. Refresh the page and log in again.", 403)
                return view(user, *args, **kwargs)
            return wrapper
        return decorator

    @app.errorhandler(StoreError)
    def handle_store_error(exc):
        """Database trouble -> clear message, HTTP 503 (service unavailable)."""
        return err(str(exc), 503)

    @app.errorhandler(Exception)
    def handle_any_error(exc):
        """Never leak stack traces to the browser."""
        code = getattr(exc, "code", None)
        if isinstance(code, int):                       # normal HTTP errors like 404 / 405
            return err(getattr(exc, "description", "Error"), code)
        log.exception("Unhandled error")
        return err("Something went wrong on the server.", 500)

    @app.after_request
    def security_headers(response):
        """Extra browser protections; API answers must never be cached."""
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "same-origin"
        if request.path.startswith("/api/"):
            response.headers["Cache-Control"] = "no-store"
        return response

    # ---- c. data shaping + validation helpers -----------------------------------
    def public_question(q):
        """Question fields that are SAFE to show a student (no answer, no explanation)."""
        keys = ("question_id", "question_text", "option_a", "option_b", "option_c",
                "option_d", "marks", "question_order")
        return {k: q[k] for k in keys}

    def exam_questions(exam_id):
        """All questions of an exam in display order."""
        qs = [q for q in db.all("Questions") if q["exam_id"] == exam_id]
        return sorted(qs, key=lambda q: int(to_float(q["question_order"])))

    def exam_view(e):
        keys = ("exam_id", "title", "description", "subject", "duration_minutes", "total_questions",
                "total_marks", "passing_percentage", "negative_marking_enabled",
                "negative_marks_per_wrong_answer", "start_datetime", "end_datetime", "status")
        return {k: e[k] for k in keys}

    def manageable_exam(user, exam_id):
        """(exam, None) if this staff user may manage it, else (None, error_response).

        Admins manage every exam; teachers only the exams they created."""
        exam = find("Exams", "exam_id", exam_id)
        if not exam:
            return None, err("Exam not found.", 404)
        if user["role"] == "teacher" and exam["created_by"] != user["user_id"]:
            return None, err("This exam belongs to another teacher.", 403)
        return exam, None

    def refresh_totals(exam_id):
        """Re-count questions and marks after any question change."""
        qs = exam_questions(exam_id)
        db.update("Exams", "exam_id", exam_id, {
            "total_questions": len(qs),
            "total_marks": sum(to_float(q["marks"]) for q in qs),
            "updated_at": now_iso(),
        })

    def validate_exam(d):
        """Return (clean_values, error_message). Used for create AND edit."""
        try:
            duration = int(d["duration_minutes"])
            passing = float(d["passing_percentage"])
            negative = float(d.get("negative_marks", 0) or 0)
        except (KeyError, ValueError, TypeError):
            return None, "Duration, passing percentage and negative marks must be numbers."
        title = str(d.get("title", "")).strip()
        if not title or len(title) > 120:
            return None, "Enter an exam title (up to 120 characters)."
        if not 1 <= duration <= 600:
            return None, "Duration must be between 1 and 600 minutes."
        if not 0 <= passing <= 100:
            return None, "Passing percentage must be between 0 and 100."
        if negative < 0 or negative > 100:
            return None, "Negative marks must be 0 or more."
        start, end = str(d.get("start_datetime", "") or ""), str(d.get("end_datetime", "") or "")
        try:
            if start and end and parse(end) <= parse(start):
                return None, "The end date must be after the start date."
        except ValueError:
            return None, "Dates must look like 2026-12-31T09:00."
        return {
            "title": title, "description": str(d.get("description", ""))[:500],
            "subject": str(d.get("subject", ""))[:80], "duration_minutes": duration,
            "passing_percentage": passing, "negative_marking_enabled": str(negative > 0).lower(),
            "negative_marks_per_wrong_answer": negative, "start_datetime": start, "end_datetime": end,
        }, None

    def validate_question(d):
        """Return (clean_values, error_message). Four options + one valid correct option required."""
        options = [str(d.get(f"option_{c}", "")).strip() for c in "abcd"]
        text = str(d.get("question_text", "")).strip()
        marks = to_float(d.get("marks", 1), -1)
        if not text or len(text) > 1000:
            return None, "Enter the question text (up to 1000 characters)."
        if not all(options) or any(len(o) > 300 for o in options):
            return None, "All four options are required (up to 300 characters each)."
        if str(d.get("correct_option", "")).upper() not in ("A", "B", "C", "D"):
            return None, "Choose the correct option (A, B, C or D)."
        if marks <= 0 or marks > 100:
            return None, "Marks must be greater than 0."
        return {
            "question_text": text, "option_a": options[0], "option_b": options[1],
            "option_c": options[2], "option_d": options[3],
            "correct_option": str(d["correct_option"]).upper(), "marks": marks,
            "explanation": str(d.get("explanation", ""))[:500],
        }, None

    # ---- d. pages + health + auth routes ----------------------------------------
    @app.get("/")
    def index():
        return render_template("app.html")

    @app.get("/api/health")
    def health():
        """Open http://127.0.0.1:5000/api/health to check the app and database are alive."""
        return ok(**db.health())

    @app.get("/api/auth/me")
    def whoami():
        user = current_user()
        if not user:
            return ok(user=None)
        session.setdefault("csrf", secrets.token_hex(16))
        return ok(user={k: user[k] for k in ("user_id", "full_name", "email", "role")}, csrf=session["csrf"])

    @app.post("/api/auth/register")
    def register():
        d = request.get_json(silent=True) or {}
        name = str(d.get("full_name", "")).strip()
        email = str(d.get("email", "")).strip().lower()
        password = str(d.get("password", ""))
        # Only student and teacher can be requested from the public form. NEVER admin.
        role = "teacher" if d.get("role") == "teacher" else "student"
        if not 2 <= len(name) <= 80 or "@" not in email or "." not in email or len(email) > 120:
            return err("Enter a valid name and email.")
        if not 8 <= len(password) <= 128:
            return err("Password must be 8 to 128 characters.")
        with WRITE_LOCK:                                   # stops two identical sign-ups racing
            if find("Users", "email", email):
                return err("This email cannot be registered. Try logging in.", 409)
            stamp = now_iso()
            db.add("Users", {
                "user_id": uid("usr"), "full_name": name, "email": email,
                "password_hash": generate_password_hash(password),
                "role": role,
                # Teachers must be approved by an administrator before they can log in.
                "status": "pending" if role == "teacher" else "active",
                "created_at": stamp, "updated_at": stamp,
            })
        if role == "teacher":
            return ok(message="Teacher account created. An administrator must approve it before you can log in."), 201
        return ok(message="Account created. You can log in now."), 201

    @app.post("/api/auth/login")
    def login():
        ip, now = request.remote_addr, datetime.now().timestamp()
        recent = [t for t in failed_logins.get(ip, []) if now - t < 300]
        if len(recent) >= 10:
            return err("Too many attempts. Wait a few minutes.", 429)
        d = request.get_json(silent=True) or {}
        user = find("Users", "email", str(d.get("email", "")).strip().lower())
        # One generic message for wrong email OR wrong password so attackers cannot learn which emails exist.
        if not user or not check_password_hash(user["password_hash"], str(d.get("password", ""))):
            failed_logins[ip] = recent + [now]
            audit("login", status="failed")
            return err("Incorrect email or password.", 401)
        # Password was right, so it is safe to explain account problems.
        if user["status"] == "pending":
            return err("Your teacher account is waiting for administrator approval.", 403)
        if user["status"] != "active":
            return err("This account has been deactivated. Contact the administrator.", 403)
        wanted = d.get("role")                              # which login tab the person used
        if wanted in ("student", "teacher", "admin") and wanted != user["role"]:
            return err(f"This is not a {wanted} account. Use the {user['role']} login tab.", 403)
        session.clear()                                     # new session id on login
        session.permanent = True
        session["uid"], session["csrf"] = user["user_id"], secrets.token_hex(16)
        audit("login", "user", user["user_id"])
        return ok(user={k: user[k] for k in ("user_id", "full_name", "email", "role")}, csrf=session["csrf"])

    @app.post("/api/auth/logout")
    def logout():
        session.clear()
        return ok()

    @app.put("/api/auth/profile")
    @auth()
    def update_profile(user):
        """Students may change their name and (with the current password) their password."""
        d = request.get_json(silent=True) or {}
        changes = {"updated_at": now_iso()}
        name = str(d.get("full_name", user["full_name"])).strip()
        if not 2 <= len(name) <= 80:
            return err("Enter a valid name.")
        changes["full_name"] = name
        if d.get("new_password"):
            if not check_password_hash(user["password_hash"], str(d.get("current_password", ""))):
                return err("Current password is incorrect.", 403)
            if not 8 <= len(str(d["new_password"])) <= 128:
                return err("New password must be 8 to 128 characters.")
            changes["password_hash"] = generate_password_hash(str(d["new_password"]))
        db.update("Users", "user_id", user["user_id"], changes)
        audit("update_profile", "user", user["user_id"])
        return ok(full_name=name)

    # ---- e. exams + questions (admin) -------------------------------------------
    @app.get("/api/exams")
    @auth()
    def list_exams(user):
        exams = db.all("Exams")
        if user["role"] == "student":                       # students only see published exams
            exams = [e for e in exams if e["status"] == "published"]
        elif user["role"] == "teacher":                     # teachers only see their own exams
            exams = [e for e in exams if e["created_by"] == user["user_id"]]
        finished = {a["exam_id"] for a in db.all("Attempts")
                    if a["user_id"] == user["user_id"] and a["status"] != "in_progress"}
        return ok(exams=[{**exam_view(e), "completed": e["exam_id"] in finished}
                         for e in exams if e["status"] != "archived" or user["role"] != "student"])

    @app.post("/api/exams")
    @auth("staff")
    def create_exam(user):
        values, problem = validate_exam(request.get_json(silent=True) or {})
        if problem:
            return err(problem)
        stamp, exam_id = now_iso(), uid("exm")
        db.add("Exams", {**values, "exam_id": exam_id, "total_questions": 0, "total_marks": 0,
                         "status": "draft", "created_by": user["user_id"], "created_at": stamp, "updated_at": stamp})
        audit("create_exam", "exam", exam_id)
        return ok(exam_id=exam_id), 201

    @app.put("/api/exams/<exam_id>")
    @auth("staff")
    def edit_exam(user, exam_id):
        exam, denied = manageable_exam(user, exam_id)
        if denied:
            return denied
        if exam["status"] != "draft":
            return err("Only draft exams can be edited. Unpublish it first.", 409)
        values, problem = validate_exam(request.get_json(silent=True) or {})
        if problem:
            return err(problem)
        db.update("Exams", "exam_id", exam_id, {**values, "updated_at": now_iso()})
        audit("edit_exam", "exam", exam_id)
        return ok()

    @app.post("/api/exams/<exam_id>/status")
    @auth("staff")
    def set_exam_status(user, exam_id):
        new_status = (request.get_json(silent=True) or {}).get("status")
        exam, denied = manageable_exam(user, exam_id)
        if denied:
            return denied
        if new_status not in ("draft", "published", "closed", "archived"):
            return err("Invalid status.")
        if new_status == "published" and not exam_questions(exam_id):
            return err("Add at least one question before publishing.")
        # Once students have attempted an exam its questions must never change again.
        if new_status == "draft" and any(a["exam_id"] == exam_id for a in db.all("Attempts")):
            return err("This exam already has attempts, so it cannot go back to draft. Close it instead.", 409)
        db.update("Exams", "exam_id", exam_id, {"status": new_status, "updated_at": now_iso()})
        audit("exam_status", "exam", exam_id, details=new_status)
        return ok()

    @app.get("/api/exams/<exam_id>/questions")
    @auth("staff")
    def admin_list_questions(user, exam_id):
        exam, denied = manageable_exam(user, exam_id)
        if denied:
            return denied
        return ok(questions=exam_questions(exam_id), exam=exam_view(exam))   # staff only: includes answer keys

    @app.post("/api/exams/<exam_id>/questions")
    @auth("staff")
    def add_question(user, exam_id):
        exam, denied = manageable_exam(user, exam_id)
        if denied:
            return denied
        if exam["status"] != "draft":
            return err("Questions can only be changed while the exam is a draft.", 409)
        values, problem = validate_question(request.get_json(silent=True) or {})
        if problem:
            return err(problem)
        stamp = now_iso()
        db.add("Questions", {**values, "question_id": uid("q"), "exam_id": exam_id,
                             "question_order": len(exam_questions(exam_id)) + 1,
                             "created_at": stamp, "updated_at": stamp})
        refresh_totals(exam_id)
        audit("add_question", "exam", exam_id)
        return ok(), 201

    @app.put("/api/questions/<question_id>")
    @auth("staff")
    def edit_question(user, question_id):
        q = find("Questions", "question_id", question_id)
        if not q:
            return err("Question not found.", 404)
        exam, denied = manageable_exam(user, q["exam_id"])
        if denied:
            return denied
        if exam["status"] != "draft":
            return err("Questions can only be changed while the exam is a draft.", 409)
        values, problem = validate_question(request.get_json(silent=True) or {})
        if problem:
            return err(problem)
        db.update("Questions", "question_id", question_id, {**values, "updated_at": now_iso()})
        refresh_totals(q["exam_id"])
        audit("edit_question", "question", question_id)
        return ok()

    @app.delete("/api/questions/<question_id>")
    @auth("staff")
    def delete_question(user, question_id):
        q = find("Questions", "question_id", question_id)
        if not q:
            return err("Question not found.", 404)
        exam, denied = manageable_exam(user, q["exam_id"])
        if denied:
            return denied
        if exam["status"] != "draft":
            return err("Questions can only be changed while the exam is a draft.", 409)
        db.delete("Questions", "question_id", question_id)
        # Close the gap in numbering so order stays 1..N.
        for number, rest in enumerate(exam_questions(q["exam_id"]), start=1):
            if int(to_float(rest["question_order"])) != number:
                db.update("Questions", "question_id", rest["question_id"], {"question_order": number})
        refresh_totals(q["exam_id"])
        audit("delete_question", "question", question_id)
        return ok()

    # ---- f. attempts (student takes the exam) -----------------------------------
    def owned_attempt(user, attempt_id):
        """An attempt, but only if it belongs to this user (stops one student touching another's)."""
        a = find("Attempts", "attempt_id", attempt_id)
        return a if a and a["user_id"] == user["user_id"] else None

    def finalize(attempt):
        """Score on the server, save the result, mark the attempt submitted.

        Safe to call twice: if a Result already exists it is returned and nothing is duplicated.
        If saving the Result fails, a StoreError is raised and the attempt stays 'in_progress',
        so the student is never told something was saved when it was not.
        """
        with WRITE_LOCK:
            existing = next((r for r in db.all("Results") if r["attempt_id"] == attempt["attempt_id"]), None)
            if existing:
                return existing
            exam = find("Exams", "exam_id", attempt["exam_id"])
            questions = exam_questions(attempt["exam_id"])
            saved = {r["question_id"]: r for r in db.all("Responses") if r["attempt_id"] == attempt["attempt_id"]}
            answers = {qid: r["selected_option"] for qid, r in saved.items() if r["selected_option"]}
            score = score_attempt(questions, answers, truthy(exam["negative_marking_enabled"]),
                                  to_float(exam["negative_marks_per_wrong_answer"]), to_float(exam["passing_percentage"]))
            for qid, (was_correct, marks) in score["detail"].items():     # per-question marking
                if qid in saved:
                    db.update("Responses", "response_id", saved[qid]["response_id"],
                              {"is_correct": str(was_correct).lower(), "marks_awarded": marks})
            result = {
                "result_id": uid("res"), "attempt_id": attempt["attempt_id"], "user_id": attempt["user_id"],
                "exam_id": attempt["exam_id"], "total_questions": len(questions),
                "correct_answers": score["correct"], "incorrect_answers": score["incorrect"],
                "unanswered_questions": score["unanswered"], "total_marks": score["total_marks"],
                "marks_obtained": score["marks_obtained"], "percentage": score["percentage"],
                "passing_percentage": exam["passing_percentage"], "result_status": score["result_status"],
                "completed_at": now_iso(),
            }
            db.add("Results", result)
            db.update("Attempts", "attempt_id", attempt["attempt_id"], {
                "status": "submitted", "submitted_at": result["completed_at"], "answered_questions": len(answers),
                "unanswered_questions": score["unanswered"], "score": score["marks_obtained"],
                "percentage": score["percentage"], "result_status": score["result_status"]})
            audit("submit_attempt", "attempt", attempt["attempt_id"])
            return result

    def result_payload(result, attempt):
        """Result + per-question review. Only called AFTER submission, so answers may be shown."""
        saved = {r["question_id"]: r for r in db.all("Responses") if r["attempt_id"] == result["attempt_id"]}
        review = []
        for q in exam_questions(result["exam_id"]):
            r = saved.get(q["question_id"], {})
            review.append({**public_question(q), "selected": r.get("selected_option", ""),
                           "correct": q["correct_option"], "is_correct": truthy(r.get("is_correct", "false")),
                           "explanation": q["explanation"]})
        exam = find("Exams", "exam_id", result["exam_id"])
        return {**result, "exam_title": exam["title"] if exam else "", "review": review}

    @app.post("/api/exams/<exam_id>/attempts")
    @auth("student")
    def start_attempt(user, exam_id):
        exam = find("Exams", "exam_id", exam_id)
        if not exam or exam["status"] != "published":
            return err("This exam is not available.", 404)
        now = datetime.now(timezone.utc)
        try:
            if exam["start_datetime"] and now < parse(exam["start_datetime"]):
                return err("This exam has not opened yet.", 403)
            if exam["end_datetime"] and now > parse(exam["end_datetime"]):
                return err("This exam has closed.", 403)
        except ValueError:
            return err("This exam has an invalid schedule. Contact the administrator.", 500)
        with WRITE_LOCK:
            mine = [a for a in db.all("Attempts") if a["user_id"] == user["user_id"] and a["exam_id"] == exam_id]
            # BUG FIX: an attempt whose time ran out but was never submitted must be finalised,
            # otherwise the student could simply start a brand-new attempt (a free retake).
            for a in mine:
                if a["status"] == "in_progress" and parse(a["expires_at"]) <= now:
                    finalize(a)
            mine = [a for a in db.all("Attempts") if a["user_id"] == user["user_id"] and a["exam_id"] == exam_id]
            live = next((a for a in mine if a["status"] == "in_progress"), None)
            if live:
                return ok(attempt_id=live["attempt_id"])    # refresh/resume: same attempt, same deadline
            if mine:
                return err("You have already completed this exam.", 409)
            attempt_id = uid("att")
            db.add("Attempts", {
                "attempt_id": attempt_id, "user_id": user["user_id"], "exam_id": exam_id,
                "attempt_number": 1, "started_at": now_iso(),
                "expires_at": (now + timedelta(minutes=int(to_float(exam["duration_minutes"])))).isoformat(timespec="seconds"),
                "status": "in_progress", "total_questions": exam["total_questions"]})
        audit("start_attempt", "attempt", attempt_id)
        return ok(attempt_id=attempt_id), 201

    @app.get("/api/attempts/<attempt_id>")
    @auth("student")
    def get_attempt(user, attempt_id):
        a = owned_attempt(user, attempt_id)
        if not a:
            return err("Attempt not found.", 404)
        if a["status"] != "in_progress":
            return err("This attempt is already submitted.", 409)
        now = datetime.now(timezone.utc)
        if now >= parse(a["expires_at"]):                   # server decides when time is up
            finalize(a)
            return err("Time is up. Your answers were submitted automatically.", 410)
        exam = find("Exams", "exam_id", a["exam_id"])
        saved = {r["question_id"]: {"selected": r["selected_option"], "review": truthy(r["marked_for_review"])}
                 for r in db.all("Responses") if r["attempt_id"] == attempt_id}
        return ok(exam=exam_view(exam), questions=[public_question(q) for q in exam_questions(a["exam_id"])],
                  responses=saved, seconds_left=int((parse(a["expires_at"]) - now).total_seconds()),
                  max_violations=config.MAX_VIOLATIONS, violations=sum(1 for v in db.all("Violations") if v["attempt_id"] == attempt_id))

    @app.put("/api/attempts/<attempt_id>/responses")
    @auth("student")
    def save_response(user, attempt_id):
        a = owned_attempt(user, attempt_id)
        if not a:
            return err("Attempt not found.", 404)
        if a["status"] != "in_progress" or datetime.now(timezone.utc) >= parse(a["expires_at"]):
            return err("This attempt is closed.", 409)
        d = request.get_json(silent=True) or {}
        question_id, selected = d.get("question_id"), d.get("selected_option") or ""
        q = find("Questions", "question_id", question_id)
        # The question must belong to THIS exam, and the answer must be A-D or empty (cleared).
        if not q or q["exam_id"] != a["exam_id"] or selected not in ("", "A", "B", "C", "D"):
            return err("Invalid answer.")
        row = {"selected_option": selected, "marked_for_review": str(bool(d.get("marked_for_review"))).lower(),
               "answered_at": now_iso()}
        with WRITE_LOCK:
            existing = next((r for r in db.all("Responses")
                             if r["attempt_id"] == attempt_id and r["question_id"] == question_id), None)
            if existing:
                db.update("Responses", "response_id", existing["response_id"], row)
            else:
                db.add("Responses", {"response_id": uid("rsp"), "attempt_id": attempt_id,
                                     "question_id": question_id, **row})
        return ok()

    @app.post("/api/attempts/<attempt_id>/submit")
    @auth("student")
    def submit_attempt(user, attempt_id):
        a = owned_attempt(user, attempt_id)
        if not a:
            return err("Attempt not found.", 404)
        result = finalize(a)                                # idempotent: double-click safe
        return ok(result=result_payload(result, find("Attempts", "attempt_id", attempt_id)))

    # ---- proctoring: tab switching, window blur, camera off ----------------------
    PROCTOR_TYPES = ("tab_switch", "window_blur", "camera_off", "camera_denied")

    @app.post("/api/attempts/<attempt_id>/violations")
    @auth("student")
    def log_violation(user, attempt_id):
        """The browser reports a rule break. The SERVER counts them and auto-submits at the limit."""
        a = owned_attempt(user, attempt_id)
        if not a:
            return err("Attempt not found.", 404)
        if a["status"] != "in_progress":
            return err("This attempt is already submitted.", 409)
        d = request.get_json(silent=True) or {}
        vtype = d.get("type")
        if vtype not in PROCTOR_TYPES:
            return err("Unknown event type.")
        limit = config.MAX_VIOLATIONS
        with WRITE_LOCK:
            mine = [v for v in db.all("Violations") if v["attempt_id"] == attempt_id]
            # Ignore an event that arrives within 2 seconds of the previous one (one tab switch often fires twice).
            if mine and (datetime.now(timezone.utc) - parse(max(v["timestamp"] for v in mine))).total_seconds() < 2:
                return ok(count=len(mine), limit=limit, auto_submitted=False)
            db.add("Violations", {"violation_id": uid("vio"), "attempt_id": attempt_id, "user_id": user["user_id"],
                                  "exam_id": a["exam_id"], "type": vtype, "timestamp": now_iso(),
                                  "details": str(d.get("details", ""))[:120]})
            count = len(mine) + 1
            if count >= limit:
                result = finalize(a)                        # too many violations -> exam ends now
                return ok(count=count, limit=limit, auto_submitted=True, result_id=result["result_id"])
        return ok(count=count, limit=limit, auto_submitted=False)

    @app.get("/api/staff/violations")
    @auth("staff")
    def staff_violations(user):
        """Proctoring log for the admin, or for a teacher's own exams."""
        users = {u["user_id"]: u for u in db.all("Users")}
        exams = {e["exam_id"]: e for e in db.all("Exams")}
        rows = []
        for v in db.all("Violations"):
            e = exams.get(v["exam_id"])
            if not e or (user["role"] == "teacher" and e["created_by"] != user["user_id"]):
                continue
            rows.append({**v, "student": users.get(v["user_id"], {}).get("full_name", ""), "exam_title": e["title"]})
        return ok(violations=sorted(rows, key=lambda r: r["timestamp"], reverse=True)[:200])

    @app.post("/api/contact")
    def contact():
        """Public contact form. Stored in the audit log so the admin can read it."""
        ip, now = request.remote_addr, datetime.now().timestamp()
        recent = [t for t in failed_logins.get("contact:" + str(ip), []) if now - t < 600]
        if len(recent) >= 5:
            return err("Too many messages. Please wait a few minutes.", 429)
        d = request.get_json(silent=True) or {}
        name, email, msg = str(d.get("name", "")).strip(), str(d.get("email", "")).strip(), str(d.get("message", "")).strip()
        if len(name) < 2 or "@" not in email or len(msg) < 5:
            return err("Please fill in your name, a valid email and a message.")
        failed_logins["contact:" + str(ip)] = recent + [now]
        audit("contact_message", details=f"{name[:30]} <{email[:40]}>: {msg[:110]}")
        return ok(message="Thanks! Your message was sent to the administrators."), 201

    # ---- g. results -------------------------------------------------------------
    @app.get("/api/results")
    @auth("student")
    def my_results(user):
        titles = {e["exam_id"]: e["title"] for e in db.all("Exams")}
        rows = [{**r, "exam_title": titles.get(r["exam_id"], "")} for r in db.all("Results")
                if r["user_id"] == user["user_id"]]
        return ok(results=sorted(rows, key=lambda r: r["completed_at"], reverse=True))

    @app.get("/api/results/<result_id>")
    @auth("student")
    def one_result(user, result_id):
        r = find("Results", "result_id", result_id)
        if not r or r["user_id"] != user["user_id"]:        # a student can only open their OWN result
            return err("Result not found.", 404)
        return ok(result=result_payload(r, find("Attempts", "attempt_id", r["attempt_id"])))

    def admin_result_rows():
        """Results joined with student + exam names, filtered by ?exam_id= ?status= ?q= ?date_from= ?date_to=."""
        viewer = current_user()
        users = {x["user_id"]: x for x in db.all("Users")}
        titles = {e["exam_id"]: e["title"] for e in db.all("Exams")}
        # Teachers only see results for exams they created; admins see everything.
        scope = None if viewer["role"] == "admin" else {e["exam_id"] for e in db.all("Exams") if e["created_by"] == viewer["user_id"]}
        strikes = {}
        for v in db.all("Violations"):
            strikes[v["attempt_id"]] = strikes.get(v["attempt_id"], 0) + 1
        args, rows = request.args, []
        needle = args.get("q", "").strip().lower()
        for r in db.all("Results"):
            if scope is not None and r["exam_id"] not in scope:
                continue
            if args.get("exam_id") and r["exam_id"] != args["exam_id"]:
                continue
            if args.get("status") and r["result_status"] != args["status"]:
                continue
            if args.get("date_from") and r["completed_at"][:10] < args["date_from"]:
                continue
            if args.get("date_to") and r["completed_at"][:10] > args["date_to"]:
                continue
            u = users.get(r["user_id"], {})
            if needle and needle not in (u.get("full_name", "") + " " + u.get("email", "")).lower():
                continue
            rows.append({**r, "student": u.get("full_name", ""), "email": u.get("email", ""),
                         "exam_title": titles.get(r["exam_id"], ""),
                         "violations": strikes.get(r["attempt_id"], 0)})
        return sorted(rows, key=lambda r: r["completed_at"], reverse=True)

    @app.get("/api/admin/results")
    @auth("staff")
    def admin_results(user):
        rows = admin_result_rows()
        try:
            page = max(int(request.args.get("page", 1)), 1)
        except ValueError:
            page = 1
        return ok(results=rows[(page - 1) * 50: page * 50], total=len(rows), page=page)

    @app.get("/api/admin/results/export")
    @auth("staff")
    def export_results(user):
        columns = ["student", "email", "exam_title", "marks_obtained", "total_marks",
                   "percentage", "result_status", "completed_at"]
        buffer = io.StringIO()
        writer = csv.writer(buffer)
        writer.writerow(columns)
        for r in admin_result_rows():
            # Prefix risky cells so Excel does not run them as formulas (CSV injection guard).
            writer.writerow(["'" + str(r[c]) if str(r[c])[:1] in "=+-@" else r[c] for c in columns])
        return Response("\ufeff" + buffer.getvalue(), mimetype="text/csv",     # BOM -> Excel reads UTF-8 names correctly
                        headers={"Content-Disposition": "attachment; filename=results.csv"})

    # ---- h. admin statistics + users --------------------------------------------
    @app.get("/api/admin/stats")
    @auth("staff")
    def admin_stats(user):
        """Dashboard numbers. Teachers see only their own exams; admins see everything."""
        exams = db.all("Exams")
        if user["role"] == "teacher":
            exams = [e for e in exams if e["created_by"] == user["user_id"]]
        ids = {e["exam_id"] for e in exams}
        results = [r for r in db.all("Results") if r["exam_id"] in ids]
        attempts = [x for x in db.all("Attempts") if x["exam_id"] in ids]
        passed = sum(1 for r in results if r["result_status"] == "PASS")
        students = (sum(1 for u in db.all("Users") if u["role"] == "student") if user["role"] == "admin"
                    else len({x["user_id"] for x in attempts}))
        return ok(students=students, exams=len(exams), attempts=len(attempts), passed=passed,
                  failed=len(results) - passed, violations=sum(1 for v in db.all("Violations") if v["exam_id"] in ids),
                  teachers=sum(1 for u in db.all("Users") if u["role"] == "teacher") if user["role"] == "admin" else 0,
                  pending=sum(1 for u in db.all("Users") if u["status"] == "pending") if user["role"] == "admin" else 0,
                  average=round(sum(to_float(r["percentage"]) for r in results) / len(results), 2) if results else 0,
                  db=db.health(),
                  recent=sorted(results, key=lambda r: r["completed_at"], reverse=True)[:5])

    @app.get("/api/admin/users")
    @auth("admin")
    def admin_users(user):
        return ok(users=[{k: u[k] for k in ("user_id", "full_name", "email", "role", "status")}
                         for u in db.all("Users")])

    @app.post("/api/admin/users/<target_id>/status")
    @auth("admin")
    def set_user_status(user, target_id):
        status = (request.get_json(silent=True) or {}).get("status")
        target = find("Users", "user_id", target_id)
        if not target:
            return err("User not found.", 404)
        if status not in ("active", "inactive") or target_id == user["user_id"] or target["role"] == "admin":
            return err("Invalid request. You cannot deactivate your own account.")
        db.update("Users", "user_id", target_id, {"status": status, "updated_at": now_iso()})
        audit("user_status", "user", target_id, details=status)
        return ok()

    @app.get("/api/admin/audit")
    @auth("admin")
    def admin_audit(user):
        return ok(logs=sorted(db.all("AuditLogs"), key=lambda r: r["timestamp"], reverse=True)[:100])

    return app


# ---------------------------------------------------------------------------
# 3. START-UP  (python app.py)
# ---------------------------------------------------------------------------
def free_port(start=5000, end=5010):
    """First port in range that nothing is listening on (fixes 'address already in use')."""
    import socket
    for port in range(start, end + 1):
        with socket.socket() as s:                           # 'with' closes the socket (old code leaked it)
            if s.connect_ex(("127.0.0.1", port)) != 0:
                return port
    return start


if __name__ == "__main__":
    application = create_app()
    port = free_port()
    print("\n" + "=" * 62)
    print(f"  ExamDesk is running:  http://127.0.0.1:{port}")
    print(f"  Storage: {application.db.kind}")
    if config.STORAGE != "google":
        print(f"  Admin login:  {config.ADMIN_EMAIL}  /  {config.ADMIN_PASSWORD}")
    print(f"  Health check: http://127.0.0.1:{port}/api/health")
    print("  Keep this window open. Press Ctrl+C to stop.")
    print("=" * 62 + "\n")
    # threaded=True lets several students use the site at once (WRITE_LOCK keeps writes safe).
    application.run(host="127.0.0.1", port=port, debug=config.DEBUG, use_reloader=False, threaded=True)
