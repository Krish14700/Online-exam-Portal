"""
Run this when something does not start:   python doctor.py
It checks Python, packages, project files, .env and the database, and says exactly what to fix.
"""
import importlib, os, sys
from pathlib import Path

BASE = Path(__file__).resolve().parent
problems = 0

def check(label, good, fix=""):
    global problems
    print(("  [ OK ] " if good else "  [FAIL] ") + label)
    if not good:
        problems += 1
        if fix: print("         -> " + fix)

print("\nExamDesk doctor\n" + "-" * 40)
check(f"Python {sys.version.split()[0]} (needs 3.9+)", sys.version_info >= (3, 9), "Install a newer Python from python.org")
# Google packages are only REQUIRED when STORAGE=google; otherwise a missing one is just a note.
needs_google = os.getenv("STORAGE", "").lower() == "google"
for pkg, pip, required in (("flask", "Flask", True), ("dotenv", "python-dotenv", False),
                           ("gspread", "gspread", needs_google), ("google.auth", "google-auth", needs_google)):
    try: importlib.import_module(pkg); good = True
    except ImportError: good = False
    if good or required: check(f"package {pip}", good, f"python -m pip install {pip}")
    else: print(f"  [skip] package {pip} not installed (only needed for Google Sheets / .env files)")

for f in ("app.py", "config.py", "services/store.py", "services/scoring_service.py", "templates/app.html", "static/app.js", "static/style.css"):
    check(f"file {f}", (BASE / f).exists(), "Re-extract the ZIP into a NEW empty folder")

# Old/different project files are the usual cause of 'SheetsDB' or 'Google Sheets is not configured' errors.
stale = BASE / "services" / "google_sheets.py"
check("no leftover services/google_sheets.py from an older version", not stale.exists(),
      "Delete services/google_sheets.py, or better: extract the ZIP into a fresh folder")
app_text = (BASE / "app.py").read_text(encoding="utf-8", errors="ignore") if (BASE / "app.py").exists() else ""
check("app.py is the current version (no SheetsDB)", "SheetsDB" not in app_text,
      "This app.py is from an older project. Replace it with the one from the ZIP")

try:
    import config
    print(f"  storage mode: {config.STORAGE}")
    from services.store import build_store, StoreError
    try:
        print("  database: " + str(build_store(config).health()))
        check("database connection", True)
    except StoreError as exc:
        check("database connection", False, str(exc))
except Exception as exc:
    check("config loads", False, f"{type(exc).__name__}: {exc}")

print("-" * 40)
print("Everything looks good. Start with: python app.py" if not problems else f"{problems} problem(s) found. Fix the lines marked FAIL, then run again.")
